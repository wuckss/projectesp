#if LV_BUILD_TEST
#include "lvgl/lvgl.h"
#include <stdio.h>

int main(void) {
	lv_init();
	return 0;
}
#endif
