#ifndef WIFI_MANAGER_H
#define WIFI_MANAGER_H

#include "esp_wifi_types.h"
#include "lvgl.h" // For lv_async_call

typedef enum {
    WIFI_STATUS_DISCONNECTED,
    WIFI_STATUS_SCANNING,
    WIFI_STATUS_CONNECTING,
    WIFI_STATUS_CONNECTED,
    WIFI_STATUS_CONNECTION_FAILED,
    WIFI_STATUS_MAX // Not a real status, for array sizing etc.
} wifi_manager_status_t;

// Callback for UI updates
typedef void (*wifi_manager_ui_update_cb_t)(wifi_manager_status_t status, void *data);
typedef void (*wifi_scan_done_cb_t)(uint16_t ap_count, wifi_ap_record_t *ap_records);


void wifi_manager_init(wifi_manager_ui_update_cb_t ui_cb, wifi_scan_done_cb_t scan_cb);
void wifi_manager_start_scan(void);
void wifi_manager_connect(const char *ssid, const char *password);
void wifi_manager_disconnect(void);
wifi_manager_status_t wifi_manager_get_status(void);
bool wifi_manager_is_connected(void);
void wifi_manager_get_saved_ssid(char* ssid_buf, size_t buf_len);

// Call this from your main LVGL timer handler or a dedicated task
void wifi_manager_task_handler(void *param); // If using a separate task for reconnect logic

#endif // WIFI_MANAGER_H