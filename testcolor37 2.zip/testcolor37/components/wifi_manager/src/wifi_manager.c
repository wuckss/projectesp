// components/wifi_manager/src/wifi_manager.c
#include "wifi_manager.h"
#include "nvs_flash.h"      // For NVS error codes like ESP_ERR_NVS_NOT_FOUND, ESP_ERR_NVS_INVALID_ARG
#include "nvs.h"            // For nvs_open, nvs_commit, nvs_close etc. (often included by nvs_flash.h)
#include "nvs_service.h"    // For your NVS functions (ensure this path is resolvable)
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "freertos/FreeRTOS.h"   // Included via wifi_manager.h but good for explicitness
#include "freertos/task.h"       // For vTaskDelay
#include "freertos/event_groups.h" // Included via wifi_manager.h
#include "string.h"
// lwip/err.h and lwip/sys.h might not be needed if ESP-IDF abstractions are used consistently.

static const char *TAG = "wifi_manager";

EventGroupHandle_t wifi_event_group;

static wifi_manager_status_t s_current_status = WIFI_MGR_STATUS_IDLE;
static wifi_ap_record_t s_ap_records_internal[WIFI_MANAGER_MAX_AP_RECORDS_INTERNAL];
static uint16_t s_ap_count_internal = 0;
static int s_retry_num = 0;

#define WIFI_NVS_NAMESPACE "wifi_cfg" 
#define NVS_KEY_WIFI_SSID "wifi_ssid" // Corrected potential typo from WIFI_NVS_
#define NVS_KEY_WIFI_PASS "wifi_pass" // Corrected potential typo

#define INITIAL_BACKOFF_MS 1000
#define MAX_BACKOFF_MS     (60*1000)
static uint32_t current_backoff_ms = INITIAL_BACKOFF_MS;
static const int WIFI_AUTO_RECONNECT_MAX_RETRIES = -1;

static wifi_manager_status_update_cb_t s_status_update_cb = NULL;
static wifi_scan_done_cb_t s_scan_done_cb = NULL;
static void *s_cb_user_data = NULL;
static bool s_user_connecting = false; 

static void invoke_status_update_cb(wifi_manager_status_t status) {
    s_current_status = status;
    if (s_status_update_cb) {
        s_status_update_cb(status, s_cb_user_data);
    }
}

void wifi_manager_attempt_reconnect_from_saved(void) {
    if (s_current_status == WIFI_MGR_STATUS_CONNECTED || s_current_status == WIFI_MGR_STATUS_CONNECTING) {
        ESP_LOGI(TAG, "Already connected or connecting, aborting reconnect attempt.");
        return;
    }

    char saved_ssid[33] = {0};
    char saved_pass[65] = {0};
    size_t ssid_len_from_nvs = sizeof(saved_ssid); // Pass buffer size, will be updated with actual length
    size_t pass_len_from_nvs = sizeof(saved_pass); // Pass buffer size, will be updated with actual length

    esp_err_t ssid_err = nvs_service_get_str(WIFI_NVS_NAMESPACE, NVS_KEY_WIFI_SSID, saved_ssid, &ssid_len_from_nvs);
    esp_err_t pass_err = nvs_service_get_str(WIFI_NVS_NAMESPACE, NVS_KEY_WIFI_PASS, saved_pass, &pass_len_from_nvs);

    if (ssid_err == ESP_OK && ssid_len_from_nvs > 0) {
        // nvs_service_get_str should handle null termination if space allows, or we ensure it here
        saved_ssid[ssid_len_from_nvs < sizeof(saved_ssid) ? ssid_len_from_nvs : sizeof(saved_ssid) - 1] = '\0';
        if (pass_err == ESP_OK) {
            saved_pass[pass_len_from_nvs < sizeof(saved_pass) ? pass_len_from_nvs : sizeof(saved_pass) - 1] = '\0';
        } else {
            saved_pass[0] = '\0'; // Ensure empty if not found or error
        }

        ESP_LOGI(TAG, "Attempting to reconnect to saved AP: %s", saved_ssid);
        wifi_config_t wifi_config = {0};
        strncpy((char*)wifi_config.sta.ssid, saved_ssid, sizeof(wifi_config.sta.ssid) - 1);
        strncpy((char*)wifi_config.sta.password, saved_pass, sizeof(wifi_config.sta.password) - 1);
        
        s_retry_num = 0;
        current_backoff_ms = INITIAL_BACKOFF_MS;
        s_user_connecting = false;

        esp_err_t set_cfg_err = esp_wifi_set_config(ESP_IF_WIFI_STA, &wifi_config);
        if (set_cfg_err != ESP_OK) {
            ESP_LOGE(TAG, "Failed to set Wi-Fi config: %s", esp_err_to_name(set_cfg_err));
            invoke_status_update_cb(WIFI_MGR_STATUS_CONNECTION_FAILED); // Or a more specific error
            return;
        }
        esp_err_t err_connect = esp_wifi_connect();
        if (err_connect == ESP_OK) {
            invoke_status_update_cb(WIFI_MGR_STATUS_CONNECTING);
        } else {
            ESP_LOGE(TAG, "Failed to issue connect command to saved AP: %s", esp_err_to_name(err_connect));
            invoke_status_update_cb(WIFI_MGR_STATUS_CONNECTION_FAILED);
        }
    } else {
        ESP_LOGI(TAG, "No valid saved SSID to reconnect to. SSID NVS err: %s", esp_err_to_name(ssid_err));
        invoke_status_update_cb(WIFI_MGR_STATUS_IDLE);
    }
}

static void wifi_event_handler(void* arg, esp_event_base_t event_base,
                               int32_t event_id, void* event_data) {
    if (event_base == WIFI_EVENT) {
        switch (event_id) {
            case WIFI_EVENT_STA_START:
                ESP_LOGI(TAG, "WIFI_EVENT_STA_START");
                invoke_status_update_cb(WIFI_MGR_STATUS_DISCONNECTED);
                wifi_manager_attempt_reconnect_from_saved();
                break;

            case WIFI_EVENT_STA_CONNECTED:
                ESP_LOGI(TAG, "WIFI_EVENT_STA_CONNECTED to AP");
                s_retry_num = 0;
                current_backoff_ms = INITIAL_BACKOFF_MS;
                break;

            case WIFI_EVENT_STA_DISCONNECTED: {
                ESP_LOGW(TAG, "WIFI_EVENT_STA_DISCONNECTED");
                wifi_event_sta_disconnected_t* disconnected_event = (wifi_event_sta_disconnected_t*) event_data;
                ESP_LOGW(TAG, "Disconnect reason: %d", disconnected_event->reason);
                xEventGroupClearBits(wifi_event_group, WIFI_EVENT_GROUP_CONNECTED_BIT);
                
                if (s_user_connecting && (
                        disconnected_event->reason == WIFI_REASON_NO_AP_FOUND ||
                        disconnected_event->reason == WIFI_REASON_AUTH_FAIL   ||
                        disconnected_event->reason == WIFI_REASON_ASSOC_FAIL  ||
                        disconnected_event->reason == WIFI_REASON_HANDSHAKE_TIMEOUT ||
                        disconnected_event->reason == WIFI_REASON_CONNECTION_FAIL ||
                        disconnected_event->reason == WIFI_REASON_4WAY_HANDSHAKE_TIMEOUT)) {
                    ESP_LOGW(TAG, "User connection attempt failed explicitly (reason: %d).", disconnected_event->reason);
                    invoke_status_update_cb(WIFI_MGR_STATUS_CONNECTION_FAILED);
                    xEventGroupSetBits(wifi_event_group, WIFI_EVENT_GROUP_FAIL_BIT);
                    s_user_connecting = false;
                    return; 
                }
                
                invoke_status_update_cb(WIFI_MGR_STATUS_DISCONNECTED);
                s_user_connecting = false;

                if (WIFI_AUTO_RECONNECT_MAX_RETRIES < 0 || s_retry_num < WIFI_AUTO_RECONNECT_MAX_RETRIES) {
                    ESP_LOGI(TAG, "Auto-reconnecting (attempt %d) in %" PRIu32 " ms...", s_retry_num + 1, current_backoff_ms);
                    vTaskDelay(pdMS_TO_TICKS(current_backoff_ms));
                    esp_wifi_connect();
                    invoke_status_update_cb(WIFI_MGR_STATUS_CONNECTING);
                    s_retry_num++;
                    current_backoff_ms = (current_backoff_ms * 2);
                    if (current_backoff_ms > MAX_BACKOFF_MS) current_backoff_ms = MAX_BACKOFF_MS;
                } else {
                    ESP_LOGE(TAG, "Failed to auto-reconnect after %d retries.", s_retry_num);
                    invoke_status_update_cb(WIFI_MGR_STATUS_CONNECTION_FAILED);
                    xEventGroupSetBits(wifi_event_group, WIFI_EVENT_GROUP_FAIL_BIT);
                }
                break;
            }
            case WIFI_EVENT_SCAN_DONE:
                ESP_LOGI(TAG, "WIFI_EVENT_SCAN_DONE");
                s_ap_count_internal = 0;
                uint16_t number = WIFI_MANAGER_MAX_AP_RECORDS_INTERNAL;
                esp_err_t err_scan = esp_wifi_scan_get_ap_records(&number, s_ap_records_internal);
                if (err_scan == ESP_OK) {
                    s_ap_count_internal = number;
                    ESP_LOGI(TAG, "Found %u APs.", s_ap_count_internal);
                } else {
                    ESP_LOGE(TAG, "Failed to get AP records: %s", esp_err_to_name(err_scan));
                }
                xEventGroupSetBits(wifi_event_group, WIFI_EVENT_GROUP_SCAN_DONE_BIT);
                invoke_status_update_cb(WIFI_MGR_STATUS_IDLE);
                if (s_scan_done_cb) {
                    s_scan_done_cb(s_ap_count_internal, s_ap_records_internal, s_cb_user_data);
                }
                break;
            default:
                break;
        }
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        ESP_LOGI(TAG, "Got IP:" IPSTR, IP2STR(&event->ip_info.ip));
        s_retry_num = 0;
        current_backoff_ms = INITIAL_BACKOFF_MS;
        
        xEventGroupSetBits(wifi_event_group, WIFI_EVENT_GROUP_CONNECTED_BIT);
        invoke_status_update_cb(WIFI_MGR_STATUS_CONNECTED);

        if(s_user_connecting) { 
            wifi_config_t current_config;
            if(esp_wifi_get_config(ESP_IF_WIFI_STA, &current_config) == ESP_OK) {
                ESP_LOGI(TAG, "User connected to %s, saving credentials.", (char*)current_config.sta.ssid);
                nvs_service_set_str(WIFI_NVS_NAMESPACE, NVS_KEY_WIFI_SSID, (char*)current_config.sta.ssid);
                nvs_service_set_str(WIFI_NVS_NAMESPACE, NVS_KEY_WIFI_PASS, (char*)current_config.sta.password);
            }
        }
        s_user_connecting = false;
    }
}

void wifi_manager_init(wifi_manager_status_update_cb_t status_cb, wifi_scan_done_cb_t scan_cb, void *cb_user_data) {
    s_status_update_cb = status_cb;
    s_scan_done_cb = scan_cb;
    s_cb_user_data = cb_user_data;
    wifi_event_group = xEventGroupCreate();
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_t *sta_netif = esp_netif_create_default_wifi_sta();
    assert(sta_netif);
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL, NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, NULL, NULL));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_LOGI(TAG, "Wi-Fi manager initialized.");
}

void wifi_manager_start_scan(void) {
    if (s_current_status == WIFI_MGR_STATUS_SCANNING) {
        ESP_LOGW(TAG, "Scan already in progress.");
        return;
    }
    ESP_LOGI(TAG, "Starting Wi-Fi scan...");
    xEventGroupClearBits(wifi_event_group, WIFI_EVENT_GROUP_SCAN_DONE_BIT);
    s_ap_count_internal = 0;
    invoke_status_update_cb(WIFI_MGR_STATUS_SCANNING);
    wifi_scan_config_t scan_config = {.ssid = NULL, .bssid = NULL, .channel = 0, .show_hidden = false, .scan_type = WIFI_SCAN_TYPE_ACTIVE,};
    esp_err_t err = esp_wifi_scan_start(&scan_config, false);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to start scan: %s", esp_err_to_name(err));
        xEventGroupSetBits(wifi_event_group, WIFI_EVENT_GROUP_SCAN_DONE_BIT);
        invoke_status_update_cb(WIFI_MGR_STATUS_IDLE);
        if (s_scan_done_cb) {
            s_scan_done_cb(0, NULL, s_cb_user_data);
        }
    }
}

esp_err_t wifi_manager_connect(const char *ssid, const char *password, bool save_credentials_flag) {
    if (!ssid || strlen(ssid) == 0) {
        return ESP_ERR_INVALID_ARG;
    }
    ESP_LOGI(TAG, "User initiated connect to SSID: %s (Save explicitly: %s)", ssid, save_credentials_flag ? "Yes" : "No");
    s_user_connecting = true; 

    wifi_config_t wifi_config = {0};
    strncpy((char*)wifi_config.sta.ssid, ssid, sizeof(wifi_config.sta.ssid) - 1);
    if (password && strlen(password) > 0) {
        strncpy((char*)wifi_config.sta.password, password, sizeof(wifi_config.sta.password) - 1);
        wifi_config.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;
    } else {
        wifi_config.sta.threshold.authmode = WIFI_AUTH_OPEN;
    }
    
    if (s_current_status == WIFI_MGR_STATUS_CONNECTED || s_current_status == WIFI_MGR_STATUS_CONNECTING) {
        ESP_LOGI(TAG, "Disconnecting existing connection before new attempt.");
        esp_wifi_disconnect();
        vTaskDelay(pdMS_TO_TICKS(500)); 
    }

    esp_err_t set_cfg_err = esp_wifi_set_config(ESP_IF_WIFI_STA, &wifi_config);
     if (set_cfg_err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set Wi-Fi config for connect: %s", esp_err_to_name(set_cfg_err));
        invoke_status_update_cb(WIFI_MGR_STATUS_CONNECTION_FAILED);
        s_user_connecting = false;
        return set_cfg_err;
    }

    s_retry_num = 0;
    current_backoff_ms = INITIAL_BACKOFF_MS;
    invoke_status_update_cb(WIFI_MGR_STATUS_CONNECTING);
    xEventGroupClearBits(wifi_event_group, WIFI_EVENT_GROUP_CONNECTED_BIT | WIFI_EVENT_GROUP_FAIL_BIT);

    esp_err_t err_connect = esp_wifi_connect();
    if (err_connect != ESP_OK) {
        ESP_LOGE(TAG, "esp_wifi_connect command failed: %s", esp_err_to_name(err_connect));
        invoke_status_update_cb(WIFI_MGR_STATUS_CONNECTION_FAILED);
        s_user_connecting = false;
        return err_connect;
    }
    // Saving is handled in IP_EVENT_STA_GOT_IP if s_user_connecting is true
    return ESP_OK;
}

void wifi_manager_disconnect(void) {
    ESP_LOGI(TAG, "Disconnecting Wi-Fi (credentials preserved).");
    s_user_connecting = false;
    esp_wifi_disconnect();
}

void wifi_manager_disconnect_and_clear_credentials(void) {
    ESP_LOGI(TAG, "Disconnecting Wi-Fi and clearing saved credentials.");
    s_user_connecting = false;
    esp_wifi_disconnect(); 
    esp_err_t err_ssid_clr = nvs_service_set_str(WIFI_NVS_NAMESPACE, NVS_KEY_WIFI_SSID, "");
    esp_err_t err_pass_clr = nvs_service_set_str(WIFI_NVS_NAMESPACE, NVS_KEY_WIFI_PASS, "");
    if(err_ssid_clr != ESP_OK || err_pass_clr != ESP_OK) {
        ESP_LOGE(TAG, "Failed to clear Wi-Fi credentials from NVS. SSID_clr_err:%s, PASS_clr_err:%s", esp_err_to_name(err_ssid_clr), esp_err_to_name(err_pass_clr));
    } else {
        ESP_LOGI(TAG, "Wi-Fi credentials cleared from NVS.");
    }
    if (s_current_status != WIFI_MGR_STATUS_DISCONNECTED && s_current_status != WIFI_MGR_STATUS_CONNECTING) {
         invoke_status_update_cb(WIFI_MGR_STATUS_IDLE);
    }
}

bool wifi_manager_is_connected(void) {
    return s_current_status == WIFI_MGR_STATUS_CONNECTED;
}

wifi_manager_status_t wifi_manager_get_current_status(void) {
    return s_current_status;
}

esp_err_t wifi_manager_get_saved_credentials(char *ssid_buf, size_t ssid_buf_len, char *pass_buf, size_t pass_buf_len) {
    esp_err_t err_ssid = ESP_ERR_NVS_INVALID_ARG; // Default to an error state
    esp_err_t err_pass = ESP_ERR_NVS_INVALID_ARG;

    size_t actual_ssid_len_val = ssid_buf_len; 
    size_t actual_pass_len_val = pass_buf_len;

    if (ssid_buf && ssid_buf_len > 0) {
        err_ssid = nvs_service_get_str(WIFI_NVS_NAMESPACE, NVS_KEY_WIFI_SSID, ssid_buf, &actual_ssid_len_val);
        if (err_ssid == ESP_OK) {
            ssid_buf[actual_ssid_len_val < ssid_buf_len ? actual_ssid_len_val : ssid_buf_len - 1] = '\0';
        } else {
            ssid_buf[0] = '\0'; 
        }
    } else if (ssid_buf == NULL && ssid_buf_len == 0) { // Requesting only password
         err_ssid = ESP_OK; // Don't treat as error if SSID buffer is NULL and len is 0
    }


    if (pass_buf && pass_buf_len > 0) {
        err_pass = nvs_service_get_str(WIFI_NVS_NAMESPACE, NVS_KEY_WIFI_PASS, pass_buf, &actual_pass_len_val);
        if (err_pass == ESP_OK) {
            pass_buf[actual_pass_len_val < pass_buf_len ? actual_pass_len_val : pass_buf_len - 1] = '\0';
        } else {
            pass_buf[0] = '\0';
        }
    } else if (pass_buf == NULL && pass_buf_len == 0) { // Requesting only SSID
        err_pass = ESP_OK; // Don't treat as error if pass buffer is NULL and len is 0
    }
    
    if (err_ssid == ESP_OK && err_pass == ESP_OK) { // Both requested and found, or one requested and found
        return ESP_OK;
    }
    
    if (err_ssid == ESP_ERR_NVS_NOT_FOUND || err_pass == ESP_ERR_NVS_NOT_FOUND) {
        ESP_LOGI(TAG, "Saved credentials (or part) not found in NVS.");
        return ESP_ERR_NVS_NOT_FOUND;
    }

    ESP_LOGE(TAG, "Error reading credentials from NVS. SSID_err: %s, PASS_err: %s", esp_err_to_name(err_ssid), esp_err_to_name(err_pass));
    return ESP_FAIL; 
}

