#include "wifi_manager.h"
#include "esp_wifi.h"
#include "esp_log.h"
#include "esp_event.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "string.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "lwip/err.h"
#include "lwip/sys.h"

#define WIFI_MANAGER_TAG "WIFI_MANAGER"
#define WIFI_NVS_NAMESPACE "wifi_creds"
#define WIFI_NVS_KEY_SSID "ssid"
#define WIFI_NVS_KEY_PASS "password"

#define MAX_APs 20

static wifi_manager_ui_update_cb_t g_ui_update_cb = NULL;
static wifi_scan_done_cb_t g_scan_done_cb = NULL;
static wifi_manager_status_t g_wifi_status = WIFI_STATUS_DISCONNECTED;

static EventGroupHandle_t wifi_event_group;
const int WIFI_CONNECTED_BIT = BIT0;
const int WIFI_FAIL_BIT = BIT1;
const int WIFI_SCAN_DONE_BIT = BIT2;

static char current_connecting_ssid[33] = {0};
static char current_connecting_password[65] = {0};

static int s_retry_num = 0;
static const int WIFI_MAX_RETRY = 10; // Max retries for initial connection
static const int WIFI_RECONNECT_MAX_RETRY = -1; // Infinite retries after first connection
static int s_reconnect_retry_num = 0;


// Forward declaration
static void attempt_reconnect_or_load_saved(void);


static void log_wifi_disconnect_reason(wifi_err_reason_t reason) {
    switch (reason) {
        case WIFI_REASON_UNSPECIFIED: ESP_LOGW(WIFI_MANAGER_TAG, "Disconnect reason: Unspecified"); break;
        case WIFI_REASON_AUTH_EXPIRE: ESP_LOGW(WIFI_MANAGER_TAG, "Disconnect reason: Auth Expired"); break;
        case WIFI_REASON_AUTH_LEAVE: ESP_LOGW(WIFI_MANAGER_TAG, "Disconnect reason: Auth Leave"); break;
        case WIFI_REASON_ASSOC_EXPIRE: ESP_LOGW(WIFI_MANAGER_TAG, "Disconnect reason: Association Expired"); break;
        // ... Add all reasons from esp_wifi_types.h
        default: ESP_LOGW(WIFI_MANAGER_TAG, "Disconnect reason: %d", reason); break;
    }
}

static void wifi_event_handler(void* arg, esp_event_base_t event_base,
                               int32_t event_id, void* event_data) {
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        ESP_LOGI(WIFI_MANAGER_TAG, "Wi-Fi STA Started. Attempting to load saved credentials or scan.");
        // Attempt to connect to saved Wi-Fi on startup
        // Moved to attempt_reconnect_or_load_saved to avoid race condition with NVS init
        // If no saved creds, UI should trigger scan.
        attempt_reconnect_or_load_saved();
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        wifi_event_sta_disconnected_t* disconnected = (wifi_event_sta_disconnected_t*) event_data;
        ESP_LOGW(WIFI_MANAGER_TAG, "Wi-Fi disconnected. SSID: %s, Reason: %d",
                 disconnected->ssid, disconnected->reason);
        log_wifi_disconnect_reason(disconnected->reason);

        g_wifi_status = WIFI_STATUS_DISCONNECTED;
        if (g_ui_update_cb) {
            // Use lv_async_call for thread safety if UI runs in a different task
            lv_async_call((lv_async_cb_t)g_ui_update_cb, (void*)WIFI_STATUS_DISCONNECTED);
        }
        xEventGroupSetBits(wifi_event_group, WIFI_FAIL_BIT); // Signal failure for connect attempts

        // Exponential backoff for reconnection
        if (s_reconnect_retry_num < 0) { // Infinite retries
             ESP_LOGI(WIFI_MANAGER_TAG, "Infinite reconnect mode. Retrying connection...");
             esp_wifi_connect();
        } else if (s_reconnect_retry_num < WIFI_RECONNECT_MAX_RETRY || WIFI_RECONNECT_MAX_RETRY == -1) {
            uint32_t delay_ms = (1 << s_reconnect_retry_num) * 1000;
            if (delay_ms > 60000) delay_ms = 60000; // Max 1 min delay
            ESP_LOGI(WIFI_MANAGER_TAG, "Retrying connection in %lu ms...", delay_ms / 1000);
            vTaskDelay(pdMS_TO_TICKS(delay_ms));
            esp_wifi_connect();
            s_reconnect_retry_num++;
        } else {
            ESP_LOGE(WIFI_MANAGER_TAG, "Failed to reconnect after max retries.");
            // Optionally, clear saved credentials if they consistently fail
            // Or trigger a full re-scan/re-configuration process
        }

    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        ESP_LOGI(WIFI_MANAGER_TAG, "Got IP: " IPSTR, IP2STR(&event->ip_info.ip));
        s_retry_num = 0;
        s_reconnect_retry_num = 0; // Reset reconnect retry counter on successful connection
        g_wifi_status = WIFI_STATUS_CONNECTED;
        if (g_ui_update_cb) {
            lv_async_call((lv_async_cb_t)g_ui_update_cb, (void*)WIFI_STATUS_CONNECTED);
        }
        xEventGroupSetBits(wifi_event_group, WIFI_CONNECTED_BIT);
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_SCAN_DONE) {
        ESP_LOGI(WIFI_MANAGER_TAG, "Scan done");
        xEventGroupSetBits(wifi_event_group, WIFI_SCAN_DONE_BIT);
        g_wifi_status = WIFI_STATUS_DISCONNECTED; // Or a new status like WIFI_STATUS_SCAN_COMPLETED

        uint16_t ap_count = 0;
        esp_wifi_scan_get_ap_num(&ap_count);
        ESP_LOGI(WIFI_MANAGER_TAG, "Found %d APs", ap_count);

        if (ap_count == 0 && g_scan_done_cb) {
            lv_async_call((lv_async_cb_t)g_scan_done_cb, NULL); // Pass NULL or specific data
            return;
        }
        if (ap_count > MAX_APs) ap_count = MAX_APs;

        wifi_ap_record_t *ap_info = (wifi_ap_record_t *)malloc(ap_count * sizeof(wifi_ap_record_t));
        if (ap_info == NULL) {
            ESP_LOGE(WIFI_MANAGER_TAG, "Failed to allocate memory for AP list");
            if (g_scan_done_cb) lv_async_call((lv_async_cb_t)g_scan_done_cb, NULL);
            return;
        }
        esp_wifi_scan_get_ap_records(&ap_count, ap_info);

        if (g_scan_done_cb) {
            // Note: ap_info is malloc'd and should be free'd by the callback receiver or after use
            lv_async_call((lv_async_cb_t)g_scan_done_cb, ap_info);
        } else {
            free(ap_info); // Free if no callback to handle it
        }
         if (g_ui_update_cb) { // Update general status if needed
            lv_async_call((lv_async_cb_t)g_ui_update_cb, (void*)WIFI_STATUS_DISCONNECTED);
        }
    }
}

static esp_err_t save_wifi_credentials(const char *ssid, const char *password) {
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open(WIFI_NVS_NAMESPACE, NVS_READWRITE, &nvs_handle);
    if (err != ESP_OK) {
        ESP_LOGE(WIFI_MANAGER_TAG, "Error (%s) opening NVS handle!", esp_err_to_name(err));
        return err;
    }

    err = nvs_set_str(nvs_handle, WIFI_NVS_KEY_SSID, ssid);
    if (err != ESP_OK) {
        ESP_LOGE(WIFI_MANAGER_TAG, "Error (%s) writing SSID to NVS!", esp_err_to_name(err));
        nvs_close(nvs_handle);
        return err;
    }

    err = nvs_set_str(nvs_handle, WIFI_NVS_KEY_PASS, password);
    if (err != ESP_OK) {
        ESP_LOGE(WIFI_MANAGER_TAG, "Error (%s) writing Password to NVS!", esp_err_to_name(err));
        nvs_close(nvs_handle);
        return err;
    }

    err = nvs_commit(nvs_handle);
    if (err != ESP_OK) {
        ESP_LOGE(WIFI_MANAGER_TAG, "Error (%s) committing NVS!", esp_err_to_name(err));
    } else {
        ESP_LOGI(WIFI_MANAGER_TAG, "Wi-Fi credentials saved for SSID: %s", ssid);
    }
    nvs_close(nvs_handle);
    return err;
}

static esp_err_t load_wifi_credentials(char *ssid_buf, size_t ssid_buf_len, char *pass_buf, size_t pass_buf_len) {
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open(WIFI_NVS_NAMESPACE, NVS_READONLY, &nvs_handle);
    if (err != ESP_OK) {
        if (err == ESP_ERR_NVS_NOT_FOUND) {
            ESP_LOGI(WIFI_MANAGER_TAG, "NVS namespace '%s' not found. No saved credentials.", WIFI_NVS_NAMESPACE);
        } else {
            ESP_LOGE(WIFI_MANAGER_TAG, "Error (%s) opening NVS handle!", esp_err_to_name(err));
        }
        return err;
    }

    err = nvs_get_str(nvs_handle, WIFI_NVS_KEY_SSID, ssid_buf, &ssid_buf_len);
    if (err != ESP_OK) {
        if(err == ESP_ERR_NVS_NOT_FOUND) ESP_LOGI(WIFI_MANAGER_TAG, "SSID not found in NVS");
        else ESP_LOGE(WIFI_MANAGER_TAG, "Error (%s) reading SSID from NVS!", esp_err_to_name(err));
        nvs_close(nvs_handle);
        return err;
    }

    err = nvs_get_str(nvs_handle, WIFI_NVS_KEY_PASS, pass_buf, &pass_buf_len);
    if (err != ESP_OK) {
         if(err == ESP_ERR_NVS_NOT_FOUND) ESP_LOGI(WIFI_MANAGER_TAG, "Password not found in NVS");
        else ESP_LOGE(WIFI_MANAGER_TAG, "Error (%s) reading Password from NVS!", esp_err_to_name(err));
        nvs_close(nvs_handle);
        return err;
    }

    ESP_LOGI(WIFI_MANAGER_TAG, "Wi-Fi credentials loaded for SSID: %s", ssid_buf);
    nvs_close(nvs_handle);
    return ESP_OK;
}


void wifi_manager_get_saved_ssid(char* ssid_buf, size_t buf_len) {
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open(WIFI_NVS_NAMESPACE, NVS_READONLY, &nvs_handle);
    if (err != ESP_OK) {
        ssid_buf[0] = '\0';
        return;
    }
    size_t required_len = buf_len;
    err = nvs_get_str(nvs_handle, WIFI_NVS_KEY_SSID, ssid_buf, &required_len);
    if (err != ESP_OK) {
        ssid_buf[0] = '\0';
    }
    nvs_close(nvs_handle);
}


void wifi_manager_init(wifi_manager_ui_update_cb_t ui_cb, wifi_scan_done_cb_t scan_cb) {
    g_ui_update_cb = ui_cb;
    g_scan_done_cb = scan_cb;
    g_wifi_status = WIFI_STATUS_DISCONNECTED;

    wifi_event_group = xEventGroupCreate();

    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    esp_event_handler_instance_t instance_any_id;
    esp_event_handler_instance_t instance_got_ip;
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                                                        ESP_EVENT_ANY_ID,
                                                        &wifi_event_handler,
                                                        NULL,
                                                        &instance_any_id));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT,
                                                        IP_EVENT_STA_GOT_IP,
                                                        &wifi_event_handler,
                                                        NULL,
                                                        &instance_got_ip));
    
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());

    ESP_LOGI(WIFI_MANAGER_TAG, "wifi_manager_init finished.");
    // Attempt to connect to saved Wi-Fi is now in WIFI_EVENT_STA_START handler via attempt_reconnect_or_load_saved
}

static void attempt_reconnect_or_load_saved(void) {
    char saved_ssid[33] = {0};
    char saved_password[65] = {0};

    if (load_wifi_credentials(saved_ssid, sizeof(saved_ssid), saved_password, sizeof(saved_password)) == ESP_OK) {
        ESP_LOGI(WIFI_MANAGER_TAG, "Found saved credentials for SSID: %s. Attempting to connect.", saved_ssid);
        wifi_manager_connect(saved_ssid, saved_password);
    } else {
        ESP_LOGI(WIFI_MANAGER_TAG, "No saved Wi-Fi credentials found or error loading them.");
        // UI should prompt for scan or show disconnected status
        if (g_ui_update_cb) {
             lv_async_call((lv_async_cb_t)g_ui_update_cb, (void*)WIFI_STATUS_DISCONNECTED);
        }
    }
}


void wifi_manager_start_scan(void) {
    ESP_LOGI(WIFI_MANAGER_TAG, "Starting Wi-Fi scan...");
    g_wifi_status = WIFI_STATUS_SCANNING;
    if (g_ui_update_cb) {
        lv_async_call((lv_async_cb_t)g_ui_update_cb, (void*)WIFI_STATUS_SCANNING);
    }
    // Ensure Wi-Fi is started, STA mode
    esp_wifi_disconnect(); // Stop any current connection attempt
    vTaskDelay(pdMS_TO_TICKS(100)); // Small delay before scan
    ESP_ERROR_CHECK(esp_wifi_scan_start(NULL, false)); // false for blocking scan (handled by event)
}


void wifi_manager_connect(const char *ssid, const char *password) {
    if (!ssid || !password) {
        ESP_LOGE(WIFI_MANAGER_TAG, "SSID or Password is NULL");
        return;
    }
    ESP_LOGI(WIFI_MANAGER_TAG, "Attempting to connect to SSID: %s", ssid);
    g_wifi_status = WIFI_STATUS_CONNECTING;

    strncpy(current_connecting_ssid, ssid, sizeof(current_connecting_ssid) - 1);
    current_connecting_ssid[sizeof(current_connecting_ssid) - 1] = '\0';
    strncpy(current_connecting_password, password, sizeof(current_connecting_password) - 1);
    current_connecting_password[sizeof(current_connecting_password) - 1] = '\0';


    if (g_ui_update_cb) {
         lv_async_call((lv_async_cb_t)g_ui_update_cb, (void*)WIFI_STATUS_CONNECTING);
    }

    wifi_config_t wifi_config = {0};
    strncpy((char*)wifi_config.sta.ssid, ssid, sizeof(wifi_config.sta.ssid) -1);
    strncpy((char*)wifi_config.sta.password, password, sizeof(wifi_config.sta.password)-1);
    wifi_config.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK; // Or determine from scan results if available
                                                          // For simplicity, assuming WPA2_PSK.
                                                          // Production code should use ap_info->authmode
    wifi_config.sta.scan_method = WIFI_FAST_SCAN; // Set scan method for connection attempts

    // Setting bssid_set to false allows ESP-IDF to determine the best AP if multiple have the same SSID
    wifi_config.sta.bssid_set = false;


    ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_STA, &wifi_config));
    
    s_retry_num = 0; // Reset initial connection retry counter
    s_reconnect_retry_num = 0; // Reset general reconnect retry counter

    esp_err_t err = esp_wifi_connect();
    if (err == ESP_OK) {
        ESP_LOGI(WIFI_MANAGER_TAG, "esp_wifi_connect call successful for %s", ssid);
        // Wait for connection events (WIFI_CONNECTED_BIT or WIFI_FAIL_BIT)
        EventBits_t bits = xEventGroupWaitBits(wifi_event_group,
                                               WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
                                               pdFALSE, // Clear on exit: No
                                               pdFALSE, // Wait for all bits: No (any bit)
                                               pdMS_TO_TICKS(15000)); // Timeout 15 seconds

        if (bits & WIFI_CONNECTED_BIT) {
            ESP_LOGI(WIFI_MANAGER_TAG, "Successfully connected to SSID: %s", ssid);
            save_wifi_credentials(ssid, password); // Save on successful connection
            g_wifi_status = WIFI_STATUS_CONNECTED;
        } else if (bits & WIFI_FAIL_BIT) {
            ESP_LOGW(WIFI_MANAGER_TAG, "Connection attempt failed for SSID: %s (event)", ssid);
            g_wifi_status = WIFI_STATUS_CONNECTION_FAILED;
        } else {
            ESP_LOGW(WIFI_MANAGER_TAG, "Connection attempt timed out for SSID: %s", ssid);
            g_wifi_status = WIFI_STATUS_CONNECTION_FAILED;
            // Manually trigger a disconnect if stuck in connecting state
            esp_wifi_disconnect();
        }
    } else {
        ESP_LOGE(WIFI_MANAGER_TAG, "esp_wifi_connect call failed: %s", esp_err_to_name(err));
        g_wifi_status = WIFI_STATUS_CONNECTION_FAILED;
    }
    
    if (g_ui_update_cb) {
        lv_async_call((lv_async_cb_t)g_ui_update_cb, (void*)g_wifi_status);
    }
    // Clear bits for next attempt
    xEventGroupClearBits(wifi_event_group, WIFI_CONNECTED_BIT | WIFI_FAIL_BIT);
}

void wifi_manager_disconnect(void) {
    ESP_LOGI(WIFI_MANAGER_TAG, "Disconnecting Wi-Fi...");
    esp_wifi_disconnect();
    // Clear saved credentials (optional, based on desired behavior)
    // nvs_handle_t nvs_handle;
    // if (nvs_open(WIFI_NVS_NAMESPACE, NVS_READWRITE, &nvs_handle) == ESP_OK) {
    //     nvs_erase_key(nvs_handle, WIFI_NVS_KEY_SSID);
    //     nvs_erase_key(nvs_handle, WIFI_NVS_KEY_PASS);
    //     nvs_commit(nvs_handle);
    //     nvs_close(nvs_handle);
    //     ESP_LOGI(WIFI_MANAGER_TAG, "Cleared saved Wi-Fi credentials.");
    // }
    g_wifi_status = WIFI_STATUS_DISCONNECTED;
    if (g_ui_update_cb) {
        lv_async_call((lv_async_cb_t)g_ui_update_cb, (void*)WIFI_STATUS_DISCONNECTED);
    }
}

wifi_manager_status_t wifi_manager_get_status(void) {
    return g_wifi_status;
}

bool wifi_manager_is_connected(void) {
    return g_wifi_status == WIFI_STATUS_CONNECTED;
}


// This task can be used for more complex reconnect logic or watchdog
void wifi_manager_task_handler(void *param) {
    while(1) {
        if (g_wifi_status == WIFI_STATUS_DISCONNECTED) {
            // This is a place for more sophisticated watchdog or auto-scan logic if needed.
            // The event handler already implements exponential backoff for reconnection.
        }
        vTaskDelay(pdMS_TO_TICKS(5000)); // Check status periodically
    }
}