// main/ui_custom_events.c
#include "ui.h"                 // For ui_obj_t declarations like ui_Roller4, ui_Coin1Container8 etc.
#include "ui_custom_events.h"
#include "wifi_manager.h"       // For wifi_manager_status_t and wifi_ap_record_t
#include "esp_log.h"
#include "ui_toast.h"           // For ui_toast_show
#include "lvgl.h"               // For lv_async_call, lv_scr_act etc.
#include "string.h"             // For strncpy, strlen, strcmp, strrchr, strcat
#include "stdlib.h"             // For malloc, free

static const char *TAG_UI_WIFI_EVTS = "ui_wifi_events";

// Store the currently selected SSID from the roller to pass to the password screen
static char g_selected_ssid_from_roller[33]; 
// Buffer for roller options. Max APs * (Max SSID length + RSSI display + newline)
// WIFI_MANAGER_MAX_AP_RECORDS_INTERNAL is 20. SSID 32 + " (-100)\n" ~10 = 42. 20*42 = 840.
static char g_roller_options_buffer[WIFI_MANAGER_MAX_AP_RECORDS_INTERNAL * 48]; 

// --- LVGL ASYNC WRAPPERS for Callbacks ---
typedef struct {
    wifi_manager_status_t status;
} wifi_status_update_param_t;

typedef struct {
    uint16_t ap_count;
    wifi_ap_record_t *ap_records; // Pointer to a copy of records
} wifi_scan_update_param_t;


// --- Callback Implementations (called by wifi_manager) ---

static void _update_wifi_status_on_ui_async(void *param) {
    wifi_status_update_param_t *p = (wifi_status_update_param_t *)param;
    lv_obj_t *current_screen = lv_scr_act(); // Get current screen for context
    ESP_LOGI(TAG_UI_WIFI_EVTS, "Async UI update for Wi-Fi status: %d", p->status);

    switch (p->status) {
        case WIFI_MGR_STATUS_SCANNING:
            if (current_screen == ui_WifiScreen && ui_Roller4) {
                lv_roller_set_options(ui_Roller4, "Scanning...", LV_ROLLER_MODE_NORMAL);
            }
            ui_toast_show(current_screen, "Scanning Wi-Fi...", 2000, false);
            break;
        case WIFI_MGR_STATUS_CONNECTING:
            ui_toast_show(current_screen, "Connecting...", 5000, false);
            if (current_screen == ui_WifiPasswordScreen1 && ui_Keyboard1) {
                 lv_obj_add_state(ui_Keyboard1, LV_STATE_DISABLED);
                 // Consider showing a spinner on ui_WifiPasswordScreen1 if you add one
            }
            break;
        case WIFI_MGR_STATUS_CONNECTED:
            ui_toast_show(current_screen, "Wi-Fi Connected!", 3000, false);
            if (current_screen == ui_WifiPasswordScreen1 && ui_Keyboard1) {
                lv_obj_clear_state(ui_Keyboard1, LV_STATE_DISABLED);
            }
            if (current_screen == ui_WifiScreen || current_screen == ui_WifiPasswordScreen1) {
                 _ui_screen_change(&ui_MainScreen, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_MainScreen_screen_init);
            }
            // TODO: Update any global Wi-Fi status indicator icon on MainScreen
            break;
        case WIFI_MGR_STATUS_CONNECTION_FAILED:
            ui_toast_show(current_screen, "Connection Failed!", 4000, true);
            if (current_screen == ui_WifiPasswordScreen1 && ui_Keyboard1) {
                lv_obj_clear_state(ui_Keyboard1, LV_STATE_DISABLED);
                if(ui_TextArea1) lv_textarea_set_text(ui_TextArea1, ""); // Clear password field
            }
            // TODO: Update any global Wi-Fi status indicator icon
            break;
        case WIFI_MGR_STATUS_DISCONNECTED:
            ui_toast_show(current_screen, "Wi-Fi Disconnected.", 3000, true);
            if (current_screen == ui_WifiPasswordScreen1 && ui_Keyboard1) {
                lv_obj_clear_state(ui_Keyboard1, LV_STATE_DISABLED);
            }
            // TODO: Update any global Wi-Fi status indicator icon
            break;
	// In main/ui_custom_events.c, inside _update_wifi_status_on_ui_async
	// ...
	    case WIFI_MGR_STATUS_IDLE:
	        if (current_screen == ui_WifiPasswordScreen1 && ui_Keyboard1) {
	            lv_obj_clear_state(ui_Keyboard1, LV_STATE_DISABLED);
	        }
	        if (current_screen == ui_WifiScreen && ui_Roller4) {
	            // To check if the roller is still showing "Scanning...", we get the full option string
	            const char * current_opts_str = lv_roller_get_options(ui_Roller4); // Correct usage
	            if(current_opts_str && strcmp(current_opts_str, "Scanning...") == 0) {
	                // This means scan_done_cb hasn't populated it yet, or it found nothing and scan_done_cb set "No networks..."
	                // The scan_done_cb should be the one to update to "No networks found" if count is 0.
	                // So, if it's still "Scanning...", it implies scan_done_cb hasn't run or had an issue.
	                // For robustness, scan_done_cb should always update the roller.
	            }
	        }
	        break;
	//...
        default:
            break;
    }
    free(p);
}

void app_wifi_status_update_callback(wifi_manager_status_t status, void *user_data) {
    ESP_LOGD(TAG_UI_WIFI_EVTS, "Wi-Fi Status Update CB: Status %d", status);
    wifi_status_update_param_t *param = malloc(sizeof(wifi_status_update_param_t));
    if (param) {
        param->status = status;
        lv_async_call(_update_wifi_status_on_ui_async, param);
    } else {
        ESP_LOGE(TAG_UI_WIFI_EVTS, "Failed to malloc for status update param");
    }
}

static void _update_wifi_list_on_ui_async(void *param) {
    wifi_scan_update_param_t *p = (wifi_scan_update_param_t *)param;
    lv_obj_t *current_screen = lv_scr_act();
    ESP_LOGI(TAG_UI_WIFI_EVTS, "Async UI update for Wi-Fi scan results: %d APs", p->ap_count);

    if (current_screen != ui_WifiScreen || !ui_Roller4) {
        ESP_LOGW(TAG_UI_WIFI_EVTS, "Not on Wi-Fi screen or ui_Roller4 is NULL. Aborting list update.");
        if(p->ap_records) free(p->ap_records);
        free(p);
        return;
    }

    if (p->ap_count == 0) {
        lv_roller_set_options(ui_Roller4, "No networks found", LV_ROLLER_MODE_NORMAL);
        ui_toast_show(current_screen, "No Wi-Fi networks found.", 3000, false);
    } else {
        g_roller_options_buffer[0] = '\0';
        size_t current_len = 0;
        for (uint16_t i = 0; i < p->ap_count; i++) {
            char entry[64]; // SSID (max 32) + " (RSSI)\n"
            snprintf(entry, sizeof(entry), "%s (%d)", (char*)p->ap_records[i].ssid, p->ap_records[i].rssi);
            
            if (current_len + strlen(entry) + ( (i < p->ap_count -1) ? 1 : 0) < sizeof(g_roller_options_buffer)) {
                strcat(g_roller_options_buffer, entry);
                if (i < p->ap_count - 1) {
                    strcat(g_roller_options_buffer, "\n");
                }
                current_len += strlen(entry) + ( (i < p->ap_count -1) ? 1 : 0);
            } else {
                ESP_LOGW(TAG_UI_WIFI_EVTS, "Roller options buffer too small for all APs. Truncating list.");
                break; 
            }
        }
        lv_roller_set_options(ui_Roller4, g_roller_options_buffer, LV_ROLLER_MODE_NORMAL);
        lv_roller_set_selected(ui_Roller4, 0, LV_ANIM_OFF);
        ui_toast_show(current_screen, "Scan complete.", 2000, false);
    }
    if(p->ap_records) free(p->ap_records);
    free(p);
}

void app_wifi_scan_done_callback(uint16_t ap_count, wifi_ap_record_t *ap_records_ptr, void *user_data) {
    ESP_LOGD(TAG_UI_WIFI_EVTS, "Wi-Fi Scan Done CB: %d APs.", ap_count);
    wifi_scan_update_param_t *param = malloc(sizeof(wifi_scan_update_param_t));
    if (!param) {
        ESP_LOGE(TAG_UI_WIFI_EVTS, "Failed to malloc for scan update param");
        return;
    }
    param->ap_count = ap_count;
    if (ap_count > 0 && ap_records_ptr) {
        param->ap_records = malloc(ap_count * sizeof(wifi_ap_record_t));
        if (param->ap_records) {
            memcpy(param->ap_records, ap_records_ptr, ap_count * sizeof(wifi_ap_record_t));
        } else {
            ESP_LOGE(TAG_UI_WIFI_EVTS, "Failed to malloc for AP records copy");
            param->ap_count = 0; 
            free(param);
            return;
        }
    } else {
        param->ap_records = NULL;
    }
    lv_async_call(_update_wifi_list_on_ui_async, param);
}

// --- Event Handlers for UI elements ---

void event_handler_go_to_wifi_screen(lv_event_t *e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) {
        ESP_LOGI(TAG_UI_WIFI_EVTS, "Navigating to Wi-Fi Screen");
        _ui_screen_change(&ui_WifiScreen, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_WifiScreen_screen_init);
    }
}

void wifi_screen_load_event_cb(lv_event_t *e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_SCREEN_LOAD_START) {
        ESP_LOGI(TAG_UI_WIFI_EVTS, "ui_WifiScreen loading, starting Wi-Fi scan.");
        if (ui_Roller4) { 
             lv_roller_set_options(ui_Roller4, "Scanning...", LV_ROLLER_MODE_NORMAL);
        }
        wifi_manager_start_scan();
    }
}

void event_handler_wifi_roller_continue(lv_event_t *e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) {
        if (ui_Roller4) {
            char selected_roller_str[128]; // Buffer for "SSID (RSSI)"
            lv_roller_get_selected_str(ui_Roller4, selected_roller_str, sizeof(selected_roller_str));
            
            char *rssi_paren = strrchr(selected_roller_str, '(');
            if (rssi_paren && rssi_paren > selected_roller_str) {
                if (*(rssi_paren - 1) == ' ') { // Check for space before '('
                    *(rssi_paren - 1) = '\0'; // Null-terminate before the space
                } else {
                    *rssi_paren = '\0'; // Fallback: null-terminate at '('
                }
            } // If no "(RSSI)" part, selected_roller_str contains the full string.

            if (strlen(selected_roller_str) == 0 || 
                strcmp(selected_roller_str, "Scanning...") == 0 ||
                strcmp(selected_roller_str, "No networks found") == 0) {
                ui_toast_show(lv_scr_act(), "Please select a valid network.", 3000, true);
                return;
            }

            strncpy(g_selected_ssid_from_roller, selected_roller_str, sizeof(g_selected_ssid_from_roller) - 1);
            g_selected_ssid_from_roller[sizeof(g_selected_ssid_from_roller) - 1] = '\0';
            ESP_LOGI(TAG_UI_WIFI_EVTS, "Wi-Fi Roller Continue for: [%s]", g_selected_ssid_from_roller);

            _ui_screen_change(&ui_WifiPasswordScreen1, LV_SCR_LOAD_ANIM_MOVE_LEFT, 200, 0, &ui_WifiPasswordScreen1_screen_init);
        }
    }
}

void password_screen_load_event_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_SCREEN_LOAD_START) {
        ESP_LOGI(TAG_UI_WIFI_EVTS, "ui_WifiPasswordScreen1 loading for SSID: %s", g_selected_ssid_from_roller);
        if (ui_TextArea1) { // This is your password input
            lv_textarea_set_text(ui_TextArea1, ""); 
        }
        if (ui_Keyboard1) { // This is your keyboard
            lv_keyboard_set_textarea(ui_Keyboard1, ui_TextArea1); 
            lv_obj_clear_state(ui_Keyboard1, LV_STATE_DISABLED); 
        }
        // You mentioned ui_PasswordSsidLabel is "none", so no label to update here.
        // If you add one later, update it here with g_selected_ssid_from_roller
    }
}

void password_submit_event_handler(lv_event_t *e) {
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t *kb = lv_event_get_target(e); 

    if (code == LV_EVENT_READY) { 
        ESP_LOGI(TAG_UI_WIFI_EVTS, "Password submitted via keyboard for SSID: %s", g_selected_ssid_from_roller);
        
        lv_obj_t *ta = lv_keyboard_get_textarea(kb);
        if (!ta) {
            ESP_LOGE(TAG_UI_WIFI_EVTS, "Keyboard has no target text area!");
            return;
        }
        const char* password = lv_textarea_get_text(ta);

        if (strlen(g_selected_ssid_from_roller) == 0) {
            ui_toast_show(lv_scr_act(), "No network selected!", 3000, true);
            return;
        }
        wifi_manager_connect(g_selected_ssid_from_roller, password, true);
    } else if (code == LV_EVENT_CANCEL) {
        ESP_LOGI(TAG_UI_WIFI_EVTS, "Password entry cancelled via keyboard.");
         _ui_screen_change(&ui_WifiScreen, LV_SCR_LOAD_ANIM_MOVE_RIGHT, 200, 0, &ui_WifiScreen_screen_init);
    }
}

void custom_ui_event_init(void) {
    ESP_LOGI(TAG_UI_WIFI_EVTS, "Initializing custom UI event handlers...");
    // Navigation to Wi-Fi Screen
    if (ui_Coin1Container8) { // From Settings Screen (was ui_SettingsButtonWifi)
      lv_obj_add_event_cb(ui_Coin1Container8, event_handler_go_to_wifi_screen, LV_EVENT_CLICKED, NULL);
    } else { ESP_LOGW(TAG_UI_WIFI_EVTS, "ui_Coin1Container8 (for Wi-Fi nav from Settings) is NULL");}
    
    if (ui_WifiDropDown) { // From Main Screen
      lv_obj_add_event_cb(ui_WifiDropDown, event_handler_go_to_wifi_screen, LV_EVENT_CLICKED, NULL);
    } else { ESP_LOGW(TAG_UI_WIFI_EVTS, "ui_WifiDropDown is NULL");}
    
    if (ui_Button9) { // "Continue" button on WifiScreen
         lv_obj_add_event_cb(ui_Button9, event_handler_wifi_roller_continue, LV_EVENT_CLICKED, NULL);
    } else { ESP_LOGW(TAG_UI_WIFI_EVTS, "ui_Button9 (Wi-Fi screen continue) is NULL");}

    if (ui_Keyboard1) { // Keyboard on Password Screen
        lv_obj_add_event_cb(ui_Keyboard1, password_submit_event_handler, LV_EVENT_READY, NULL);
        lv_obj_add_event_cb(ui_Keyboard1, password_submit_event_handler, LV_EVENT_CANCEL, NULL);
    } else { ESP_LOGW(TAG_UI_WIFI_EVTS, "ui_Keyboard1 is NULL");}

    // Settings Screen events (using confirmed names)
    if(ui_Button2) { // Restart Button 
        lv_obj_add_event_cb(ui_Button2, event_handler_restart_button, LV_EVENT_CLICKED, NULL);
    } else { ESP_LOGW(TAG_UI_WIFI_EVTS, "ui_Button2 (Restart) is NULL");}

    if(ui_Slider4) { // Brightness Slider
        lv_obj_add_event_cb(ui_Slider4, event_handler_brightness_slider, LV_EVENT_VALUE_CHANGED, NULL);
    } else { ESP_LOGW(TAG_UI_WIFI_EVTS, "ui_Slider4 (Brightness) is NULL");}

    if(ui_Switch2) { // Theme Toggle
        lv_obj_add_event_cb(ui_Switch2, event_handler_theme_switch, LV_EVENT_VALUE_CHANGED, NULL);
    } else { ESP_LOGW(TAG_UI_WIFI_EVTS, "ui_Switch2 (Theme) is NULL");}

    // Placeholder for OTA button if you add it later
    // if(ui_SettingsCheckUpdateButton) { 
    //    lv_obj_add_event_cb(ui_SettingsCheckUpdateButton, event_handler_check_for_update_button, LV_EVENT_CLICKED, NULL);
    // }
    ESP_LOGI(TAG_UI_WIFI_EVTS, "Custom UI event handlers initialization attempt complete.");
}

void app_wifi_manager_register_callbacks(void) {
    wifi_manager_init(app_wifi_status_update_callback, app_wifi_scan_done_callback, NULL);
}

// Dummy implementations for Settings event handlers to allow compilation
// Replace these with actual logic later.
void event_handler_restart_button(lv_event_t *e) {ESP_LOGI(TAG_UI_WIFI_EVTS, "Restart button pressed - no action yet.");}
void event_handler_brightness_slider(lv_event_t *e) {ESP_LOGI(TAG_UI_WIFI_EVTS, "Brightness slider changed - no action yet.");}
void event_handler_theme_switch(lv_event_t *e) {ESP_LOGI(TAG_UI_WIFI_EVTS, "Theme switch toggled - no action yet.");}
void event_handler_check_for_update_button(lv_event_t *e) {ESP_LOGI(TAG_UI_WIFI_EVTS, "Check for update pressed - no action yet.");}

