#include "theme_manager.h"
#include "nvs_service.h"
#include "esp_log.h"

#define THEME_MANAGER_TAG "THEME_MANAGER"

static app_theme_t current_app_theme = THEME_LIGHT; // Default

void theme_manager_init(void) {
    uint8_t is_dark_theme;
    if (nvs_service_get_u8(THEME_NVS_NAMESPACE, THEME_NVS_KEY, &is_dark_theme) == ESP_OK) {
        current_app_theme = (is_dark_theme == 1) ? THEME_DARK : THEME_LIGHT;
        ESP_LOGI(THEME_MANAGER_TAG, "Loaded theme: %s", current_app_theme == THEME_DARK ? "Dark" : "Light");
    } else {
        ESP_LOGI(THEME_MANAGER_TAG, "No saved theme, defaulting to Light theme.");
        current_app_theme = THEME_LIGHT; // Default
        theme_manager_save_theme(current_app_theme);
    }
    // Initial application will be done in main after LVGL display is initialized
}

void theme_manager_apply_theme(lv_disp_t *disp, app_theme_t theme_mode) {
    if (!disp) disp = lv_disp_get_default();
    if (!disp) return;

    lv_theme_t *th;
    if (theme_mode == THEME_DARK) {
        th = lv_theme_default_init(disp, lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_RED),
                                   true, LV_FONT_DEFAULT); // Dark theme
        ESP_LOGI(THEME_MANAGER_TAG, "Applying Dark Theme");
    } else {
        th = lv_theme_default_init(disp, lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_RED),
                                   false, LV_FONT_DEFAULT); // Light theme
        ESP_LOGI(THEME_MANAGER_TAG, "Applying Light Theme");
    }
    lv_disp_set_theme(disp, th);
    current_app_theme = theme_mode;

    // You might need to refresh all screens or invalidate objects to fully apply theme changes
    // For example, by re-creating screens or explicitly setting styles on key elements
    // A simple way is to reload the current screen:
    // lv_scr_load_anim(lv_scr_act(), LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, false); // Example
}

app_theme_t theme_manager_get_current_theme(void) {
    return current_app_theme;
}

void theme_manager_toggle_theme(lv_disp_t *disp) {
    app_theme_t new_theme = (current_app_theme == THEME_LIGHT) ? THEME_DARK : THEME_LIGHT;
    theme_manager_apply_theme(disp, new_theme);
    theme_manager_save_theme(new_theme);
}

void theme_manager_save_theme(app_theme_t theme_mode) {
    uint8_t is_dark = (theme_mode == THEME_DARK) ? 1 : 0;
    esp_err_t err = nvs_service_set_u8(THEME_NVS_NAMESPACE, THEME_NVS_KEY, is_dark);
    if (err == ESP_OK) {
        ESP_LOGI(THEME_MANAGER_TAG, "Theme (%s) saved to NVS.", theme_mode == THEME_DARK ? "Dark" : "Light");
    } else {
        ESP_LOGE(THEME_MANAGER_TAG, "Failed to save theme to NVS: %s", esp_err_to_name(err));
    }
}