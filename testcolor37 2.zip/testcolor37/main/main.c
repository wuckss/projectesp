#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_timer.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_touch.h"
#include "esp_log.h"
#include "esp_err.h"
#include "driver/gpio.h" // For ESP.restart()
#include "esp_system.h"  // For esp_restart()


#include "lvgl.h"
// Assuming your SquareLine Studio export provides these or similar includes
#include "ui/ui.h"          // Main UI export from SLS
#include "ui/ui_helpers.h"  // UI helpers from SLS
#include "ui/ui_events.h"   // UI event handlers (may need modification)

// Your custom services
#include "nvs_service.h"
#include "wifi_manager.h"
#include "backlight_control.h"
#include "theme_manager.h"
#include "ui_toast.h"
#include "ota_service.h"
#include "levenshtein.h" // For selector screen search

// You'll need to include headers for your display and touch drivers
// e.g. #include "esp_lcd_gc9a01.h"
// e.g. #include "esp_lcd_touch_gt911.h"
#include "components/espressif__esp_lcd_touch/include/esp_lcd_touch.h" // Generic touch
#include "components/espressif__esp_lcd_touch_gt911/include/esp_lcd_touch_gt911.h" // Specific for GT911
// Add your specific display driver includes here based on Waveshare 7-inch configuration

#define MAIN_TAG "MAIN_APP"

// LVGL Display and Input Buffers
#define LV_HOR_RES_MAX          (800) // Your display's horizontal resolution
#define LV_VER_RES_MAX          (480) // Your display's vertical resolution
#define LVGL_TICK_PERIOD_MS     (CONFIG_LV_DISP_DEF_REFR_PERIOD) // Typically 10-30ms

static lv_disp_draw_buf_t disp_buf;
static lv_color_t *lv_disp_buf1 = NULL;
static lv_color_t *lv_disp_buf2 = NULL; // Optional: for double buffering

static lv_disp_drv_t disp_drv;
static lv_indev_drv_t indev_drv;
static esp_lcd_touch_handle_t tp = NULL; // Touch panel handle

// Forward declarations for UI interaction logic
static void ui_event_restart_button_cb(lv_event_t * e);
static void ui_event_brightness_slider_cb(lv_event_t * e);
static void ui_event_theme_toggle_cb(lv_event_t * e);
static void ui_event_ota_check_button_cb(lv_event_t * e);
static void ui_event_selector_search_cb(lv_event_t * e);
static void ui_event_wifi_scan_button_cb(lv_event_t * e);
static void ui_event_wifi_connect_button_cb(lv_event_t * e);
static void ui_event_wifi_list_item_select_cb(lv_event_t * e);


// --- Crypto Data Stubs ---
// Replace with actual data fetching and parsing logic
#define MAX_CRYPTO_COINS 8
typedef struct {
    char name[32];
    char symbol[8];
    char logo_path[128]; // Path to image, or use LVGL symbols/imgfont
    double price;
    double change_24h_percent;
    double change_24h_absolute;
    double market_cap;
    double all_time_high;
    // Add more fields as needed
} crypto_coin_data_t;

crypto_coin_data_t displayed_coins[MAX_CRYPTO_COINS];
int num_displayed_coins = 0;

// --- Wi-Fi Scan Results ---
#define MAX_SCAN_RESULTS 15
static wifi_ap_record_t ap_records_buffer[MAX_SCAN_RESULTS];
static uint16_t num_ap_records = 0;
static char selected_ssid_for_password[33];


// LVGL Tick and Task
static void lvgl_tick_cb(void *arg) {
    (void)arg;
    lv_tick_inc(LVGL_TICK_PERIOD_MS);
}

static void lvgl_task(void *pvParameter) {
    ESP_LOGI(MAIN_TAG, "Starting LVGL task");
    while (1) {
        lv_timer_handler();
        vTaskDelay(pdMS_TO_TICKS(LVGL_TICK_PERIOD_MS));
    }
}

// Display flush callback
static void disp_flush_cb(lv_disp_drv_t *drv, const lv_area_t *area, lv_color_t *color_p) {
    esp_lcd_panel_handle_t panel_handle = (esp_lcd_panel_handle_t) drv->user_data;
    int offsetx1 = area->x1;
    int offsetx2 = area->x2;
    int offsety1 = area->y1;
    int offsety2 = area->y2;
    esp_lcd_panel_draw_bitmap(panel_handle, offsetx1, offsety1, offsetx2 + 1, offsety2 + 1, color_p);
    lv_disp_flush_ready(drv);
}

// Touch input read callback
static void touchpad_read_cb(lv_indev_drv_t *indev_drv, lv_indev_data_t *data) {
    uint16_t touch_x[1] = {0};
    uint16_t touch_y[1] = {0};
    uint8_t touch_cnt = 0;

    esp_err_t ret = esp_lcd_touch_read_data(tp);
    if (ret != ESP_OK) {
        ESP_LOGE(MAIN_TAG, "Touch read error: %s", esp_err_to_name(ret));
        data->state = LV_INDEV_STATE_REL;
        return;
    }

    bool touched = esp_lcd_touch_get_coordinates(tp, touch_x, touch_y, NULL, &touch_cnt, 1);
    if (touched && touch_cnt > 0) {
        data->point.x = touch_x[0];
        data->point.y = touch_y[0];
        data->state = LV_INDEV_STATE_PR;
        ESP_LOGD(MAIN_TAG, "Touch: X=%u, Y=%u", data->point.x, data->point.y);
    } else {
        data->state = LV_INDEV_STATE_REL;
    }
}

// Wi-Fi Manager Callbacks
void wifi_ui_update_callback(wifi_manager_status_t status, void *data) {
    const char *status_str = "Unknown";
    bool is_error_toast = false;
    switch (status) {
        case WIFI_STATUS_DISCONNECTED: status_str = "Wi-Fi: Disconnected"; is_error_toast = true; break;
        case WIFI_STATUS_SCANNING: status_str = "Wi-Fi: Scanning..."; break;
        case WIFI_STATUS_CONNECTING: status_str = "Wi-Fi: Connecting..."; break;
        case WIFI_STATUS_CONNECTED: status_str = "Wi-Fi: Connected!"; break;
        case WIFI_STATUS_CONNECTION_FAILED: status_str = "Wi-Fi: Connection Failed!"; is_error_toast = true; break;
        default: break;
    }
    ESP_LOGI(MAIN_TAG, "Wi-Fi Status Update: %s", status_str);
    ui_toast_show(NULL, status_str, 3000, is_error_toast);

    // Update a global Wi-Fi status label on the main screen if you have one
    // Assuming ui_WifiStatusLabel is a label on your main screen or a header
    if (ui_WifiStatusLabel) { // Replace with your actual Wi-Fi status label ID
         lv_label_set_text(ui_WifiStatusLabel, status == WIFI_STATUS_CONNECTED ? LV_SYMBOL_WIFI : "No Wi-Fi");
    }

    if (status == WIFI_STATUS_DISCONNECTED || status == WIFI_STATUS_CONNECTION_FAILED) {
        // If connection fails or disconnects, perhaps navigate to Wi-Fi screen or show scan option
        // For now, just a toast.
    } else if (status == WIFI_STATUS_CONNECTED) {
        // Fetch crypto data on successful connection
        // placeholder_fetch_crypto_data();
    }
}

void wifi_scan_done_ui_callback(uint16_t ap_count_from_event, wifi_ap_record_t *ap_records_from_event) {
    // This callback receives `ap_records_from_event` which was malloc'd in wifi_manager.
    // It must be freed here after use.

    ESP_LOGI(MAIN_TAG, "Wi-Fi Scan Done UI Callback. APs found: %u", ap_count_from_event);
    num_ap_records = 0; // Reset our local buffer count

    if (ap_count_from_event > 0 && ap_records_from_event != NULL) {
        num_ap_records = (ap_count_from_event > MAX_SCAN_RESULTS) ? MAX_SCAN_RESULTS : ap_count_from_event;
        memcpy(ap_records_buffer, ap_records_from_event, num_ap_records * sizeof(wifi_ap_record_t));
        free(ap_records_from_event); // Free the malloc'd memory
    } else if (ap_records_from_event != NULL) {
        free(ap_records_from_event); // Free even if count is 0
    }


    // Populate your ui_WifiList (assuming it's an lv_list object on ui_WifiScreen)
    // This needs to be adapted to your exact UI structure from SquareLine Studio.
    // Example:
    // lv_obj_clean(ui_WifiList); // Clear previous items

    if (ui_WifiList) { // Replace with your actual Wi-Fi list widget ID
        lv_obj_clean(ui_WifiList); // Clear previous entries
        if (num_ap_records == 0) {
            lv_obj_t* lbl = lv_list_add_text(ui_WifiList, "No networks found");
            // Style label if needed
        } else {
            for (uint16_t i = 0; i < num_ap_records; i++) {
                char item_text[64];
                snprintf(item_text, sizeof(item_text), "%s (%d) %s",
                         (char*)ap_records_buffer[i].ssid,
                         ap_records_buffer[i].rssi,
                         (ap_records_buffer[i].authmode == WIFI_AUTH_OPEN) ? LV_SYMBOL_UNLOCK : LV_SYMBOL_LOCK);
                
                lv_obj_t *btn = lv_list_add_btn(ui_WifiList, NULL, item_text);
                lv_obj_add_event_cb(btn, ui_event_wifi_list_item_select_cb, LV_EVENT_CLICKED, (void*)(intptr_t)i);
            }
        }
         _ui_screen_change( &ui_WifiScreen, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_WifiScreen_screen_init);
    } else {
        ESP_LOGE(MAIN_TAG, "ui_WifiList object not found!");
    }
     ui_toast_show(NULL, "Scan complete", 2000, false);
}


// OTA Status Callback
void ota_ui_callback(ota_status_t status, int progress) {
    char toast_msg[100];
    bool is_error = false;
    uint32_t duration = 3000;

    switch (status) {
        case OTA_IDLE: strcpy(toast_msg, "OTA: Idle"); break;
        case OTA_IN_PROGRESS: snprintf(toast_msg, sizeof(toast_msg), "OTA: Updating... %d%%", progress); duration = 10000; break; // Longer for progress
        case OTA_SUCCESS: strcpy(toast_msg, "OTA: Success! Rebooting..."); break;
        case OTA_FAILED: strcpy(toast_msg, "OTA: Failed!"); is_error = true; break;
        case OTA_NO_UPDATE_AVAILABLE: strcpy(toast_msg, "OTA: No update available."); break;
        default: strcpy(toast_msg, "OTA: Unknown status"); is_error = true; break;
    }
    ui_toast_show(NULL, toast_msg, duration, is_error);
    ESP_LOGI(MAIN_TAG, "OTA Status: %s", toast_msg);

    // Optionally update a progress bar on the settings screen
    // if (ui_OtaProgressBar && status == OTA_IN_PROGRESS) {
    //    lv_bar_set_value(ui_OtaProgressBar, progress, LV_ANIM_ON);
    // }
}

void app_main(void) {
    ESP_LOGI(MAIN_TAG, "Application Start");

    // 1. Initialize NVS
    nvs_service_init();

    // 2. Initialize Backlight Control (depends on NVS)
    backlight_control_init(); // Ensure this is called AFTER NVS and BEFORE LVGL init if LVGL uses it

    // 3. Initialize LVGL
    lv_init();

    // Allocate LVGL draw buffers
    // Using MALLOC_CAP_DMA for potential DMA transfer with display controller
    // Using MALLOC_CAP_INTERNAL for SPIRAM if available and preferred for large buffers
    // Adjust size based on your display resolution and color depth
    // For 800x480 at 16bpp (LV_COLOR_DEPTH 16), a full buffer is 800*480*2 bytes = 768KB.
    // A 1/10th screen size buffer is more common: 800 * 48 * 2 bytes = 76.8KB
    size_t buf_size_bytes = LV_HOR_RES_MAX * (LV_VER_RES_MAX / 10) * (LV_COLOR_DEPTH / 8);
    
    // Try to allocate from SPIRAM first if available, otherwise internal RAM
    #if CONFIG_SPIRAM_USE_MALLOC
    lv_disp_buf1 = heap_caps_malloc(buf_size_bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    #else
    lv_disp_buf1 = heap_caps_malloc(buf_size_bytes, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    #endif

    if (lv_disp_buf1 == NULL) {
        ESP_LOGE(MAIN_TAG, "Failed to allocate LVGL display buffer 1 from preferred memory. Trying internal.");
        lv_disp_buf1 = malloc(buf_size_bytes); // Fallback to standard malloc
    }
    // If using two buffers:
    // lv_disp_buf2 = heap_caps_malloc(buf_size_bytes, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);

    if (lv_disp_buf1 == NULL /*|| lv_disp_buf2 == NULL (if using two) */) {
        ESP_LOGE(MAIN_TAG, "FATAL: Failed to allocate LVGL display buffer(s)!");
        // Handle error: perhaps restart or indicate critical failure. For now, assert.
        assert(lv_disp_buf1 != NULL);
    }
    lv_disp_draw_buf_init(&disp_buf, lv_disp_buf1, NULL /*lv_disp_buf2*/, LV_HOR_RES_MAX * (LV_VER_RES_MAX / 10));


    // 4. Initialize Display Driver
    ESP_LOGI(MAIN_TAG, "Initialize LCD panel");
    esp_lcd_panel_handle_t panel_handle = NULL;
    // --- YOUR DISPLAY INITIALIZATION CODE HERE ---
    // This is highly specific to your Waveshare 7-inch display (e.g. controller ST7262, RGB interface)
    // Refer to ESP-IDF LCD examples for RGB panel initialization.
    // Example placeholder (replace with actual init):
    // esp_lcd_rgb_panel_config_t panel_config = { /* ... */ };
    // ESP_ERROR_CHECK(esp_lcd_new_rgb_panel(&panel_config, &panel_handle));
    // ESP_ERROR_CHECK(esp_lcd_panel_reset(panel_handle));
    // ESP_ERROR_CHECK(esp_lcd_panel_init(panel_handle));
    // ESP_ERROR_CHECK(esp_lcd_panel_disp_on_off(panel_handle, true));
    // --- END OF YOUR DISPLAY INITIALIZATION ---
    if (!panel_handle) {
        ESP_LOGE(MAIN_TAG, "Display panel initialization failed!");
        assert(panel_handle != NULL); // Stop if display fails
    }


    ESP_LOGI(MAIN_TAG, "Initialize LVGL display driver");
    lv_disp_drv_init(&disp_drv);
    disp_drv.hor_res = LV_HOR_RES_MAX;
    disp_drv.ver_res = LV_VER_RES_MAX;
    disp_drv.flush_cb = disp_flush_cb;
    disp_drv.draw_buf = &disp_buf;
    disp_drv.user_data = panel_handle; // Pass panel handle to flush_cb
    // disp_drv.full_refresh = 1; // Enable if your display requires full refresh
    lv_disp_t *disp = lv_disp_drv_register(&disp_drv);
    if (!disp) {
         ESP_LOGE(MAIN_TAG, "LVGL Display driver registration failed!");
         assert(disp != NULL);
    }


    // 5. Initialize Touch Driver
    ESP_LOGI(MAIN_TAG, "Initialize touch panel");
    esp_lcd_touch_config_t tp_cfg = {
        .x_max = LV_HOR_RES_MAX,
        .y_max = LV_VER_RES_MAX,
        .rst_gpio_num = GPIO_NUM_NC, // Or your actual RST pin
        .int_gpio_num = GPIO_NUM_NC, // Or your actual INT pin
        .levels = {
            .reset = 0,
            .interrupt = 0,
        },
        .flags = {
            .swap_xy = 0, // Adjust as per your touch panel
            .mirror_x = 0,// Adjust as per your touch panel
            .mirror_y = 0,// Adjust as per your touch panel
        }
    };
    // Assuming I2C for touch, configure I2C pins
    // ESP_ERROR_CHECK(i2c_param_config(TOUCH_I2C_HOST, &i2c_conf)); // Your I2C init
    // ESP_ERROR_CHECK(i2c_driver_install(TOUCH_I2C_HOST, I2C_MODE_MASTER, 0, 0, 0));

    // For GT911 (example)
    ESP_ERROR_CHECK(esp_lcd_touch_new_i2c_gt911(NULL /* Your I2C bus handle */, &tp_cfg, &tp));
     if (!tp) {
         ESP_LOGE(MAIN_TAG, "Touch panel initialization failed!");
         assert(tp != NULL);
     }


    lv_indev_drv_init(&indev_drv);
    indev_drv.type = LV_INDEV_TYPE_POINTER;
    indev_drv.disp = disp;
    indev_drv.read_cb = touchpad_read_cb;
    indev_drv.user_data = tp;
    lv_indev_t *touch_indev = lv_indev_drv_register(&indev_drv);
     if (!touch_indev) {
         ESP_LOGE(MAIN_TAG, "LVGL Input driver registration failed!");
         assert(touch_indev != NULL);
     }


    // 6. Initialize Theme Manager and Apply Theme (depends on NVS and LVGL display)
    theme_manager_init();
    theme_manager_apply_theme(disp, theme_manager_get_current_theme());

    // 7. Initialize UI (from SquareLine Studio)
    ui_init(); // This typically loads the first screen

    // 8. Initialize Wi-Fi Manager (depends on NVS, UI for callbacks)
    wifi_manager_init(wifi_ui_update_callback, wifi_scan_done_ui_callback);
    // xTaskCreate(wifi_manager_task_handler, "wifi_task", 4096, NULL, 5, NULL); // Optional separate task

    // 9. Initialize OTA Service
    ota_service_init(ota_ui_callback);

    // 10. Create LVGL Tick Timer and Task
    const esp_timer_create_args_t lvgl_tick_timer_args = {
        .callback = &lvgl_tick_cb,
        .name = "lvgl_tick"
    };
    esp_timer_handle_t lvgl_tick_timer = NULL;
    ESP_ERROR_CHECK(esp_timer_create(&lvgl_tick_timer_args, &lvgl_tick_timer));
    ESP_ERROR_CHECK(esp_timer_start_periodic(lvgl_tick_timer, LVGL_TICK_PERIOD_MS * 1000)); // Period in microseconds

    // Create LVGL task with specific core if needed, adjust stack size
    // For dual core ESP32-S3, can pin to core 1 if core 0 is busy (e.g. with Wi-Fi/BT)
    xTaskCreatePinnedToCore(lvgl_task, "lvgl_task", CONFIG_LV_TASK_STACK_SIZE, NULL, CONFIG_LV_TASK_PRIORITY, NULL, 1);

    ESP_LOGI(MAIN_TAG, "Initialization complete. LVGL running.");

    // --- Placeholder: Example for MainScreen data population ---
    // This should be called after Wi-Fi connects and data is fetched
    // placeholder_populate_main_screen();

    // --- Placeholder: Example for SelectorScreen population ---
    // This might be called after a search query
    // placeholder_populate_selector_screen();
}

// --- Dummy UI Event Handlers (to be connected in SquareLine or ui_events.c) ---
// You should connect these to the `LV_EVENT_CLICKED` or `LV_EVENT_VALUE_CHANGED` events
// of the respective widgets in your SquareLine Studio project or `ui_events.c`.

// Placeholder for Restart Button
static void ui_event_restart_button_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) {
        ESP_LOGI(MAIN_TAG, "Restart button clicked. Confirming...");
        // Create a confirmation dialog
        lv_obj_t * mbox = lv_msgbox_create(NULL, "Confirm Restart", "Are you sure you want to restart the device?", NULL, true);
        lv_obj_t * btn_ok = lv_msgbox_add_footer_button(mbox, "Restart");
        lv_obj_t * btn_cancel = lv_msgbox_add_footer_button(mbox, "Cancel");

        lv_obj_add_event_cb(btn_ok, [](lv_event_t * ev) {
            ESP_LOGI(MAIN_TAG, "Restart confirmed. Restarting now.");
            ui_toast_show(NULL,"Restarting...", 2000, false);
            vTaskDelay(pdMS_TO_TICKS(500)); // Allow toast to show briefly
            esp_restart();
        }, LV_EVENT_CLICKED, NULL);

        lv_obj_add_event_cb(btn_cancel, [](lv_event_t * ev) {
            lv_msgbox_close(lv_event_get_current_target(ev)); // Close this msgbox
        }, LV_EVENT_CLICKED, NULL);
        lv_obj_center(mbox);
    }
}

// Placeholder for Brightness Slider
static void ui_event_brightness_slider_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * slider = lv_event_get_target(e);

    if (code == LV_EVENT_VALUE_CHANGED) {
        int32_t value = lv_slider_get_value(slider);
        backlight_set_brightness((uint8_t)value);
        ESP_LOGD(MAIN_TAG, "Brightness changed to: %d%%", (uint8_t)value);
    } else if (code == LV_EVENT_RELEASED || code == LV_EVENT_PRESS_LOST) { // Save on release
        int32_t value = lv_slider_get_value(slider);
        backlight_save_brightness((uint8_t)value);
        ESP_LOGI(MAIN_TAG, "Brightness %d%% saved.", (uint8_t)value);
    }
}

// Placeholder for Theme Toggle (e.g., a switch or button)
static void ui_event_theme_toggle_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    // lv_obj_t * toggle_switch = lv_event_get_target(e); // If it's a switch

    if (code == LV_EVENT_CLICKED /* or LV_EVENT_VALUE_CHANGED for a switch */) {
        theme_manager_toggle_theme(lv_disp_get_default());
        ESP_LOGI(MAIN_TAG, "Theme toggled. Current: %s",
                 theme_manager_get_current_theme() == THEME_DARK ? "Dark" : "Light");
        // Update the switch state if it's a switch widget
        // if (ui_ThemeSwitch) { // Assuming ui_ThemeSwitch is your switch widget ID
        //    lv_obj_set_state(ui_ThemeSwitch,
        //                     theme_manager_get_current_theme() == THEME_DARK ? LV_STATE_CHECKED : 0,
        //                     LV_ANIM_OFF);
        // }
    }
}

// Placeholder for OTA Check Button
static void ui_event_ota_check_button_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) {
        if (wifi_manager_is_connected()) {
            ESP_LOGI(MAIN_TAG, "Check for OTA Update button clicked.");
            // Replace with your actual OTA binary URL from AWS S3
            const char *ota_url = "YOUR_S3_OTA_BIN_URL_HERE"; // e.g., "https://your-bucket.s3.amazonaws.com/firmware.bin"
            if (strcmp(ota_url, "YOUR_S3_OTA_BIN_URL_HERE") == 0) {
                 ui_toast_show(NULL, "OTA URL not configured!", 3000, true);
                 ESP_LOGE(MAIN_TAG, "OTA URL is not configured in ota_service_start_update.");
                 return;
            }
            ota_service_start_update(ota_url);
        } else {
            ui_toast_show(NULL, "Connect to Wi-Fi first!", 3000, true);
            ESP_LOGW(MAIN_TAG, "OTA check attempted without Wi-Fi connection.");
        }
    }
}

// Placeholder for Wi-Fi Scan Button (on WifiScreen or SettingsScreen)
static void ui_event_wifi_scan_button_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) {
        ESP_LOGI(MAIN_TAG, "Wi-Fi Scan button clicked.");
        wifi_manager_start_scan();
        // UI will be updated by wifi_scan_done_ui_callback
    }
}


// Placeholder for Wi-Fi List Item Click (on ui_WifiScreen)
static void ui_event_wifi_list_item_select_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * btn = lv_event_get_target(e);
    intptr_t item_idx = (intptr_t)lv_event_get_user_data(e);


    if (code == LV_EVENT_CLICKED && item_idx < num_ap_records) {
        wifi_ap_record_t *selected_ap = &ap_records_buffer[item_idx];
        strncpy(selected_ssid_for_password, (char*)selected_ap->ssid, sizeof(selected_ssid_for_password)-1);
        selected_ssid_for_password[sizeof(selected_ssid_for_password)-1] = '\0';

        ESP_LOGI(MAIN_TAG, "Selected Wi-Fi: %s", selected_ssid_for_password);

        if (selected_ap->authmode == WIFI_AUTH_OPEN) {
            ESP_LOGI(MAIN_TAG, "Network is open. Connecting to %s...", selected_ssid_for_password);
            wifi_manager_connect(selected_ssid_for_password, ""); // Empty password for open network
            // Optionally, navigate away or show connecting status directly
        } else {
            // Navigate to WifiPasswordScreen or show a password input dialog
            // For simplicity, assuming you have ui_WifiPasswordScreen1 from SLS
            // And ui_PasswordTextArea and ui_PasswordSSIDLabel on that screen
            ESP_LOGI(MAIN_TAG, "Network requires password. Showing password screen for %s.", selected_ssid_for_password);
            if(ui_PasswordSSIDLabel) lv_label_set_text(ui_PasswordSSIDLabel, selected_ssid_for_password);
            if(ui_PasswordTextArea) lv_textarea_set_text(ui_PasswordTextArea, ""); // Clear previous password
             _ui_screen_change(&ui_WifiPasswordScreen1, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_WifiPasswordScreen1_screen_init);
        }
    }
}


// Placeholder for Wi-Fi Connect Button (on WifiPasswordScreen1)
static void ui_event_wifi_connect_button_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) {
        // Assuming ui_PasswordTextArea exists on WifiPasswordScreen1
        if (ui_PasswordTextArea) { // Replace with your actual password text area ID
            const char* password = lv_textarea_get_text(ui_PasswordTextArea);
            ESP_LOGI(MAIN_TAG, "Connect button clicked for SSID: %s", selected_ssid_for_password);
            if (strlen(selected_ssid_for_password) > 0) {
                wifi_manager_connect(selected_ssid_for_password, password);
                // The wifi_ui_update_callback will handle feedback.
                // Optionally, navigate back to main screen or show a connecting spinner.
                // For now, assume user stays on password screen until connection status is updated by toast
                 _ui_screen_change(&ui_MainScreen, LV_SCR_LOAD_ANIM_FADE_ON, 200, 0, &ui_MainScreen_screen_init); // Example: Go to main after attempt
            } else {
                ESP_LOGE(MAIN_TAG, "No SSID selected for connection.");
                ui_toast_show(NULL, "No SSID selected!", 2000, true);
            }
        } else {
            ESP_LOGE(MAIN_TAG, "Password text area (ui_PasswordTextArea) not found!");
        }
    }
}



// Placeholder for SelectorScreen search icon click / text input change
// This assumes you have a search icon (e.g., ui_SelectorSearchIcon)
// and a text area for input (e.g., ui_SelectorSearchInput)
static void ui_event_selector_search_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t * ta = lv_event_get_target(e); // Assuming event is on the text area

    if (code == LV_EVENT_READY || code == LV_EVENT_DEFOCUSED) { // Or LV_EVENT_VALUE_CHANGED if you want live search
        const char *query = lv_textarea_get_text(ta);
        ESP_LOGI(MAIN_TAG, "Selector Search: %s", query);

        if (strlen(query) < 1 && code != LV_EVENT_DEFOCUSED) { // Minimum query length, allow empty on defocus to clear
            // Clear results if query is too short
            // placeholder_populate_selector_screen(NULL, 0);
            return;
        }

        // --- STUB: AWS Backend Call ---
        // In a real app, you'd make an HTTP request to your AWS backend here with the query.
        // The backend would return a list of matching coins.
        // For now, simulate with a local list and Levenshtein.
        ESP_LOGI(MAIN_TAG, "Simulating backend search for: %s", query);
        
        // Example local coin list (replace with actual data source)
        crypto_coin_data_t all_possible_coins[] = {
            {"Bitcoin", "BTC", "S:/path/to/btc.png", 0,0,0,0,0}, // Use "S:" for SPIFFS/SD if images are there
            {"Ethereum", "ETH", "S:/path/to/eth.png",0,0,0,0,0},
            {"Cardano", "ADA", "S:/path/to/ada.png",0,0,0,0,0},
            {"Solana", "SOL", "S:/path/to/sol.png",0,0,0,0,0},
            {"Dogecoin", "DOGE", "S:/path/to/doge.png",0,0,0,0,0},
            {"Ripple", "XRP", "S:/path/to/xrp.png",0,0,0,0,0},
            {"Polkadot", "DOT", "S:/path/to/dot.png",0,0,0,0,0},
            {"Litecoin", "LTC", "S:/path/to/ltc.png",0,0,0,0,0},
            // Add more coins
        };
        int num_all_coins = sizeof(all_possible_coins) / sizeof(all_possible_coins[0]);
        
        num_displayed_coins = 0;
        for (int i = 0; i < num_all_coins && num_displayed_coins < MAX_CRYPTO_COINS; i++) {
            int dist_name = levenshtein_distance(query, all_possible_coins[i].name);
            int dist_symbol = levenshtein_distance(query, all_possible_coins[i].symbol);
            // Simple match: exact symbol or close name (Levenshtein <= 2)
            if (strcasecmp(query, all_possible_coins[i].symbol) == 0 || 
                (strlen(query) > 1 && (dist_name <= 2 || strcasestr(all_possible_coins[i].name, query) != NULL) )) {
                displayed_coins[num_displayed_coins++] = all_possible_coins[i];
            }
        }
        
        // Update the selector screen tiles
        // placeholder_populate_selector_screen(displayed_coins, num_displayed_coins);
        // This function would iterate through your ui_CoinTile1, ui_CoinNameLabel1, ui_CoinLogoImg1 etc.
        // and update them. Unused tiles should be hidden.
        // Example:
        for (int i = 0; i < MAX_CRYPTO_COINS; i++) {
            // Get references to tile elements, e.g., ui_CoinTileContainer[i], ui_CoinNameLabel[i], ui_CoinLogoImage[i]
            // These IDs need to be defined in your ui_SelectorScreen.c from SquareLine.
            // For this example, assume you have arrays of these objects:
            // extern lv_obj_t * ui_SelectorCoinTiles[MAX_CRYPTO_COINS]; // Panel for the tile
            // extern lv_obj_t * ui_SelectorCoinLogos[MAX_CRYPTO_COINS]; // Image widget
            // extern lv_obj_t * ui_SelectorCoinNames[MAX_CRYPTO_COINS]; // Label widget

            if (ui_SelectorCoinTiles && i < num_displayed_coins) { // Check if array is defined
                 // lv_obj_clear_flag(ui_SelectorCoinTiles[i], LV_OBJ_FLAG_HIDDEN);
                 // lv_img_set_src(ui_SelectorCoinLogos[i], displayed_coins[i].logo_path);
                 // lv_label_set_text(ui_SelectorCoinNames[i], displayed_coins[i].name);
            } else if (ui_SelectorCoinTiles) {
                 // lv_obj_add_flag(ui_SelectorCoinTiles[i], LV_OBJ_FLAG_HIDDEN);
            }
        }
         ui_toast_show(NULL, "Search results updated.", 1500, false);
    }
}


// --- Placeholder data update functions ---
void placeholder_fetch_crypto_data() {
    // STUB: In a real app, this would make an HTTP request to a crypto API
    // and parse the JSON response.
    ESP_LOGI(MAIN_TAG, "Stub: Fetching crypto data...");
    // For now, populate with dummy data
    // placeholder_populate_main_screen_with_data(/* some dummy data */);
}

void placeholder_populate_main_screen_with_data(crypto_coin_data_t* coin) {
    if (!coin) return;

    // Assume these LVGL label objects exist on ui_MainScreen
    // You MUST replace these with the actual object names from your ui_MainScreen.c
    // extern lv_obj_t *ui_MainCoinNameLabel;
    // extern lv_obj_t *ui_MainPriceLabel;
    // extern lv_obj_t *ui_Main24hChangePercentLabel;
    // extern lv_obj_t *ui_Main24hChangeAbsoluteLabel;
    // extern lv_obj_t *ui_MainMarketCapLabel;
    // extern lv_obj_t *ui_MainATHLabel;
    // extern lv_obj_t *ui_MainScreenChart; // Assuming this is your chart object

    char buffer[64];

    // if (ui_MainCoinNameLabel) lv_label_set_text(ui_MainCoinNameLabel, coin->name);

    snprintf(buffer, sizeof(buffer), "$%.2f", coin->price);
    // if (ui_MainPriceLabel) lv_label_set_text(ui_MainPriceLabel, buffer);

    snprintf(buffer, sizeof(buffer), "%.2f%%", coin->change_24h_percent);
    // if (ui_Main24hChangePercentLabel) {
    //    lv_label_set_text(ui_Main24hChangePercentLabel, buffer);
    //    lv_obj_set_style_text_color(ui_Main24hChangePercentLabel,
    //                                coin->change_24h_percent >= 0 ? lv_palette_main(LV_PALETTE_GREEN) : lv_palette_main(LV_PALETTE_RED),
    //                                0);
    // }
    // ... and so on for other labels

    // Update chart (example with dummy data)
    // if (ui_MainScreenChart) {
    //    lv_chart_series_t * ser = lv_chart_get_series(ui_MainScreenChart, 0); // Assuming one series
    //    if(ser) {
    //        lv_chart_set_ext_y_array(ui_MainScreenChart, ser, (lv_coord_t[]){10, 20, 15, 30, 25, 40, 35}); // Example
    //        lv_chart_refresh(ui_MainScreenChart); // Redraw chart
    //    }
    // }
    ESP_LOGI(MAIN_TAG, "Stub: Main screen updated with data for %s", coin->name);
}


/*
* This function should be called from ui_events.c or where you setup event handlers
* for the widgets in SquareLine Studio.
*
* Example in ui_events.c:
*
* void AddCustomEventHandlers(void) {
* if(ui_SettingsRestartBtn) lv_obj_add_event_cb(ui_SettingsRestartBtn, ui_event_restart_button_cb, LV_EVENT_CLICKED, NULL);
* if(ui_SettingsBrightnessSlider) lv_obj_add_event_cb(ui_SettingsBrightnessSlider, ui_event_brightness_slider_cb, LV_EVENT_ALL, NULL);
* if(ui_SettingsThemeToggle) lv_obj_add_event_cb(ui_SettingsThemeToggle, ui_event_theme_toggle_cb, LV_EVENT_CLICKED, NULL);
* if(ui_SettingsOtaCheckBtn) lv_obj_add_event_cb(ui_SettingsOtaCheckBtn, ui_event_ota_check_button_cb, LV_EVENT_CLICKED, NULL);
* if(ui_WifiScreenScanBtn) lv_obj_add_event_cb(ui_WifiScreenScanBtn, ui_event_wifi_scan_button_cb, LV_EVENT_CLICKED, NULL);
* if(ui_WifiPasswordScreenConnectBtn) lv_obj_add_event_cb(ui_WifiPasswordScreenConnectBtn, ui_event_wifi_connect_button_cb, LV_EVENT_CLICKED, NULL);
* if(ui_SelectorSearchTextArea) lv_obj_add_event_cb(ui_SelectorSearchTextArea, ui_event_selector_search_cb, LV_EVENT_ALL, NULL);
*
* // For MainScreen elements, updates are usually data-driven, not direct event handlers for labels.
* // But if you have a refresh button on MainScreen:
* // if(ui_MainScreenRefreshBtn) lv_obj_add_event_cb(ui_MainScreenRefreshBtn, refresh_main_screen_data_event, LV_EVENT_CLICKED, NULL);
* }
*
* Then call AddCustomEventHandlers(); from your ui_init() function in ui.c,
* or from app_main after ui_init().
*/