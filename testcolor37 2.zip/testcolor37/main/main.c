// In main.c
#include "ui.h"
#include "ui_custom_events.h" // For app_wifi_manager_register_callbacks and custom_ui_event_init
#include "nvs_service.h"    // For nvs_service_init
#include "wifi_manager.h"   // For wifi_manager_init (indirectly via app_wifi_manager_register_callbacks)
#include "backlight_control.h"
#include "theme_manager.h"
// ... other includes

static const char *TAG_MAIN = "app_main";

static void lvgl_task(void *pvParameter) { /* ... as before ... */ }

void app_main(void) {
    ESP_LOGI(TAG_MAIN, "App Main started.");

    nvs_service_init();
    ESP_LOGI(TAG_MAIN, "NVS Initialized.");

    backlight_control_init();
    // ... load saved brightness ...
    ESP_LOGI(TAG_MAIN, "Backlight Initialized.");
    
    bsp_display_start();
    bsp_display_backlight_on();
    lv_disp_t *disp = bsp_display_lvgl_init();
    
    ui_init(); // Creates all SquareLine UI objects, including screens
    ESP_LOGI(TAG_MAIN, "LVGL UI Initialized (ui_init done).");

    // Initialize custom event system FIRST, which registers callbacks with wifi_manager
    app_wifi_manager_register_callbacks(); // This calls wifi_manager_init
    ESP_LOGI(TAG_MAIN, "Wi-Fi Manager Initialized & Callbacks Registered.");
    
    // THEN, initialize custom UI event handlers that might use wifi_manager functions or rely on UI objects
    custom_ui_event_init(); 
    ESP_LOGI(TAG_MAIN, "Custom UI Event Handlers Initialized.");

    // Add screen load event handlers AFTER ui_init() has created the screen objects
    if(ui_WifiScreen) {
        lv_obj_add_event_cb(ui_WifiScreen, wifi_screen_load_event_cb, LV_EVENT_SCREEN_LOAD_START, NULL);
    } else { ESP_LOGE(TAG_MAIN, "ui_WifiScreen object is NULL during event setup!"); }
    if(ui_WifiPasswordScreen1) {
        lv_obj_add_event_cb(ui_WifiPasswordScreen1, password_screen_load_event_cb, LV_EVENT_SCREEN_LOAD_START, NULL);
    } else { ESP_LOGE(TAG_MAIN, "ui_WifiPasswordScreen1 object is NULL during event setup!"); }


    theme_manager_init(disp);
    theme_manager_load_and_apply_theme();
    ESP_LOGI(TAG_MAIN, "Theme Manager Initialized.");

    xTaskCreate(lvgl_task, "lvgl_task", 4096 * 2, NULL, CONFIG_BSP_DISPLAY_LVGL_TASK_PRIORITY, NULL);
    ESP_LOGI(TAG_MAIN, "LVGL Task Created.");

    // Initial Wi-Fi status will be handled by callbacks now.
    // wifi_manager_attempt_reconnect_from_saved() is called from WIFI_EVENT_STA_START
    // so no explicit call here is needed if that behavior is desired.

    ESP_LOGI(TAG_MAIN, "Initialization complete.");
}