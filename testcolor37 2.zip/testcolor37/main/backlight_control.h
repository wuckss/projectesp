#ifndef BACKLIGHT_CONTROL_H
#define BACKLIGHT_CONTROL_H

#include <stdint.h>

#define BRIGHTNESS_NVS_NAMESPACE "display_cfg"
#define BRIGHTNESS_NVS_KEY "brightness"

void backlight_control_init(void);
void backlight_set_brightness(uint8_t percentage); // 0-100
uint8_t backlight_get_brightness(void);
void backlight_save_brightness(uint8_t percentage);

#endif // BACKLIGHT_CONTROL_H