#include "levenshtein.h"
#include <string.h>
#include <stdlib.h>

#define MIN3(a, b, c) ((a) < (b) ? ((a) < (c) ? (a) : (c)) : ((b) < (c) ? (b) : (c)))

int levenshtein_distance(const char *s1, const char *s2) {
    unsigned int s1len, s2len, x, y, lastdiag, olddiag;
    s1len = strlen(s1);
    s2len = strlen(s2);

    if (s1len == 0) return s2len;
    if (s2len == 0) return s1len;

    unsigned int *column = (unsigned int*) calloc(s1len + 1, sizeof(unsigned int));
    if (!column) return -1; // Error case

    for (y = 1; y <= s1len; y++)
        column[y] = y;

    for (x = 1; x <= s2len; x++) {
        column[0] = x;
        lastdiag = x - 1;
        for (y = 1; y <= s1len; y++) {
            olddiag = column[y];
            column[y] = MIN3(column[y] + 1, column[y - 1] + 1, lastdiag + (s1[y - 1] == s2[x - 1] ? 0 : 1));
            lastdiag = olddiag;
        }
    }
    int result = column[s1len];
    free(column);
    return result;
}