#include "backlight_control.h"
#include "driver/ledc.h"
#include "esp_log.h"
#include "nvs_service.h" // Use your NVS service

#define BACKLIGHT_TAG "BACKLIGHT"

// Configure these to your hardware
#define LEDC_TIMER              LEDC_TIMER_0
#define LEDC_MODE               LEDC_LOW_SPEED_MODE // Or LEDC_HIGH_SPEED_MODE
#define LEDC_OUTPUT_IO          (CONFIG_EXAMPLE_PIN_NUM_BK_LIGHT) // From Kconfig or define directly
#define LEDC_CHANNEL            LEDC_CHANNEL_0
#define LEDC_DUTY_RES           LEDC_TIMER_10_BIT // Resolution of PWM duty, e.g., 10-bit for 0-1023
#define LEDC_FREQUENCY          (5000) // Frequency in Hertz

static uint8_t current_brightness_percent = 100;

void backlight_control_init(void) {
    // Prepare and then apply the LEDC PWM timer configuration
    ledc_timer_config_t ledc_timer = {
        .speed_mode       = LEDC_MODE,
        .timer_num        = LEDC_TIMER,
        .duty_resolution  = LEDC_DUTY_RES,
        .freq_hz          = LEDC_FREQUENCY,
        .clk_cfg          = LEDC_AUTO_CLK
    };
    ESP_ERROR_CHECK(ledc_timer_config(&ledc_timer));

    // Prepare and then apply the LEDC PWM channel configuration
    ledc_channel_config_t ledc_channel = {
        .speed_mode     = LEDC_MODE,
        .channel        = LEDC_CHANNEL,
        .timer_sel      = LEDC_TIMER,
        .intr_type      = LEDC_INTR_DISABLE,
        .gpio_num       = LEDC_OUTPUT_IO,
        .duty           = 0, // Set duty to 0% initially
        .hpoint         = 0
    };
    ESP_ERROR_CHECK(ledc_channel_config(&ledc_channel));
    ESP_LOGI(BACKLIGHT_TAG, "Backlight PWM initialized on GPIO %d", LEDC_OUTPUT_IO);

    // Load saved brightness
    uint8_t saved_brightness;
    if (nvs_service_get_u8(BRIGHTNESS_NVS_NAMESPACE, BRIGHTNESS_NVS_KEY, &saved_brightness) == ESP_OK) {
        if (saved_brightness <= 100) { // Basic validation
             current_brightness_percent = saved_brightness;
             ESP_LOGI(BACKLIGHT_TAG, "Loaded brightness: %d%%", current_brightness_percent);
        } else {
            ESP_LOGW(BACKLIGHT_TAG, "Invalid saved brightness: %d%%, defaulting to 100%%", saved_brightness);
            current_brightness_percent = 100; // Default
            backlight_save_brightness(current_brightness_percent);
        }
    } else {
        ESP_LOGI(BACKLIGHT_TAG, "No saved brightness, defaulting to 100%%");
        current_brightness_percent = 100; // Default
        backlight_save_brightness(current_brightness_percent);
    }
    backlight_set_brightness(current_brightness_percent);
}

void backlight_set_brightness(uint8_t percentage) {
    if (percentage > 100) percentage = 100;
    current_brightness_percent = percentage;

    // Convert percentage to duty cycle value
    // For 10-bit resolution (0-1023), max_duty is 1023.
    // Duty = (percentage / 100) * max_duty
    uint32_t max_duty = (1 << LEDC_DUTY_RES) - 1;
    uint32_t duty = (percentage * max_duty) / 100;

    ESP_ERROR_CHECK(ledc_set_duty(LEDC_MODE, LEDC_CHANNEL, duty));
    ESP_ERROR_CHECK(ledc_update_duty(LEDC_MODE, LEDC_CHANNEL));
    ESP_LOGD(BACKLIGHT_TAG, "Brightness set to %d%% (duty: %lu)", percentage, duty);
}

uint8_t backlight_get_brightness(void) {
    return current_brightness_percent;
}

void backlight_save_brightness(uint8_t percentage) {
    if (percentage > 100) percentage = 100;
    esp_err_t err = nvs_service_set_u8(BRIGHTNESS_NVS_NAMESPACE, BRIGHTNESS_NVS_KEY, percentage);
    if (err == ESP_OK) {
        ESP_LOGI(BACKLIGHT_TAG, "Brightness %d%% saved to NVS.", percentage);
    } else {
        ESP_LOGE(BACKLIGHT_TAG, "Failed to save brightness to NVS: %s", esp_err_to_name(err));
    }
}