#include "ui_toast.h"
#include "esp_log.h"

#define UI_TOAST_TAG "UI_TOAST"

static void toast_delete_cb(lv_event_t * e) {
    lv_obj_t * toast = lv_event_get_target(e);
    lv_obj_del_async(toast); // Use async delete
    ESP_LOGD(UI_TOAST_TAG, "Toast deleted by timer");
}

void ui_toast_show(lv_obj_t* parent_screen, const char* message, uint32_t duration_ms, bool is_error) {
    if (!parent_screen) {
        parent_screen = lv_scr_act(); // Default to active screen
    }
    if (!parent_screen) return;


    // Check if an old toast exists and delete it
    lv_obj_t *old_toast = lv_obj_get_child(parent_screen, -1); // Check last child
    if(old_toast && lv_obj_check_type(old_toast, &lv_label_class) && lv_obj_has_flag(old_toast, LV_OBJ_FLAG_FLOATING)) {
         // A simple way to identify our toast by checking if it's a floating label. More robust: use user_data.
        ESP_LOGD(UI_TOAST_TAG, "Deleting existing toast.");
        lv_timer_t* old_timer = (lv_timer_t*)lv_obj_get_user_data(old_toast);
        if(old_timer) lv_timer_del(old_timer);
        lv_obj_del(old_toast);
    }


    lv_obj_t *toast_label = lv_label_create(parent_screen);
    lv_label_set_text(toast_label, message);
    lv_obj_set_width(toast_label, LV_PCT(80)); // 80% of parent width
    lv_obj_set_style_bg_opa(toast_label, LV_OPA_COVER, 0);
    lv_obj_set_style_bg_color(toast_label, is_error ? lv_palette_main(LV_PALETTE_RED) : lv_palette_main(LV_PALETTE_GREY), 0);
    lv_obj_set_style_text_color(toast_label, lv_color_white(), 0);
    lv_obj_set_style_pad_all(toast_label, 10, 0);
    lv_obj_set_style_radius(toast_label, 5, 0);
    lv_obj_set_style_text_align(toast_label, LV_TEXT_ALIGN_CENTER, 0);

    lv_obj_align(toast_label, LV_ALIGN_BOTTOM_MID, 0, -20); // Position at bottom
    lv_obj_add_flag(toast_label, LV_OBJ_FLAG_FLOATING); // Ensure it's on top


    ESP_LOGI(UI_TOAST_TAG, "Showing toast: %s", message);

    lv_timer_t * timer = lv_timer_create(toast_delete_cb, duration_ms, toast_label);
    lv_timer_set_repeat_count(timer, 1); // Run only once
    lv_obj_set_user_data(toast_label, timer); // Store timer to allow deletion if new toast appears
}