// components/ui/include/ui_events.h
#ifndef _UI_EVENTS_H // Use the guard from your existing ui_events.h
#define _UI_EVENTS_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"

// Original SquareLine event function declarations
void restartdevicefunction(lv_event_t *e);
void passwordsubmitted(lv_event_t *e);

// New declarations for Wi-Fi UI interaction
void ui_events_set_selected_ssid(const char* ssid);
const char* ui_events_get_selected_ssid(void);

// Toast message helper (async wrapper)
// message_ptr should be a dynamically allocated string (e.g., from strdup)
// This wrapper will queue the call to the actual LVGL task.
void show_toast_message_async_wrapper(void* message_ptr);

// LVGL task callback - DO NOT CALL DIRECTLY from non-LVGL tasks.
// It will be called by LVGL's async mechanism.
// It is responsible for freeing the message_ptr.
void show_toast_task_cb(void *param);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif /* _UI_EVENTS_H */