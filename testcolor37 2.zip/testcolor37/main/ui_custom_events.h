#ifndef UI_CUSTOM_EVENTS_H
#define UI_CUSTOM_EVENTS_H

#include "lvgl.h"

void ui_custom_events_init(void); // Call this after ui_init()

#endif // UI_CUSTOM_EVENTS_H