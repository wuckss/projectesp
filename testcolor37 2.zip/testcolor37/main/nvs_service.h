#ifndef NVS_SERVICE_H
#define NVS_SERVICE_H

#include "esp_err.h"
#include <stdbool.h>
#include <stdint.h>

void nvs_service_init(void);

// Generic NVS functions
esp_err_t nvs_service_set_str(const char* namespace_name, const char* key, const char* value);
esp_err_t nvs_service_get_str(const char* namespace_name, const char* key, char* out_value, size_t* length);
esp_err_t nvs_service_set_u8(const char* namespace_name, const char* key, uint8_t value);
esp_err_t nvs_service_get_u8(const char* namespace_name, const char* key, uint8_t* out_value);
esp_err_t nvs_service_set_i32(const char* namespace_name, const char* key, int32_t value);
esp_err_t nvs_service_get_i32(const char* namespace_name, const char* key, int32_t* out_value);

#endif // NVS_SERVICE_H