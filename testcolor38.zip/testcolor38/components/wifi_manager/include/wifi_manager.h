#ifndef WIFI_MANAGER_H
#define WIFI_MANAGER_H

#include "esp_wifi_types.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
// #include "lvgl.h" // Not strictly needed here if UI updates are via callbacks to UI layer

#define WIFI_MANAGER_MAX_AP_RECORDS_INTERNAL 20 // Internal buffer size

// Event group bits (can be kept internal to .c if not exposed, or used by tasks waiting on Wi-Fi)
#define WIFI_EVENT_GROUP_CONNECTED_BIT BIT0
#define WIFI_EVENT_GROUP_FAIL_BIT      BIT1
#define WIFI_EVENT_GROUP_SCAN_DONE_BIT BIT2

extern EventGroupHandle_t wifi_event_group; // Keep if tasks outside wifi_manager need to wait

typedef enum {
    WIFI_MGR_STATUS_DISCONNECTED,
    WIFI_MGR_STATUS_SCANNING,
    WIFI_MGR_STATUS_CONNECTING,
    WIFI_MGR_STATUS_CONNECTED,
    WIFI_MGR_STATUS_CONNECTION_FAILED,
    WIFI_MGR_STATUS_IDLE, // Added for a neutral state
    WIFI_MGR_STATUS_MAX // Not a real status, for array sizing etc.
} wifi_manager_status_t; // Renamed to avoid conflict if your other enum is used elsewhere

// Callback for general UI/status updates
typedef void (*wifi_manager_status_update_cb_t)(wifi_manager_status_t status, void *user_data);

// Callback specifically for scan results
// esp_wifi_scan_get_ap_records already provides wifi_ap_record_t
typedef void (*wifi_scan_done_cb_t)(uint16_t ap_count, wifi_ap_record_t *ap_records, void *user_data);

void wifi_manager_init(wifi_manager_status_update_cb_t status_cb, wifi_scan_done_cb_t scan_cb, void *cb_user_data);
void wifi_manager_start_scan(void);
esp_err_t wifi_manager_connect(const char *ssid, const char *password, bool save_credentials);
void wifi_manager_disconnect_and_clear_credentials(void); // More explicit name
void wifi_manager_disconnect(void); // Just disconnect, keep credentials
wifi_manager_status_t wifi_manager_get_current_status(void); // Renamed for clarity
bool wifi_manager_is_connected(void);
esp_err_t wifi_manager_get_saved_credentials(char *ssid_buf, size_t ssid_buf_len, char *pass_buf, size_t pass_buf_len);
// void wifi_manager_get_saved_ssid(char* ssid_buf, size_t buf_len); // Covered by get_saved_credentials

// If you still want a dedicated task handler for some internal periodic checks, keep it.
// Otherwise, event-driven logic in wifi_event_handler might be sufficient.
// void wifi_manager_task_handler(void *param);

#endif // WIFI_MANAGER_H