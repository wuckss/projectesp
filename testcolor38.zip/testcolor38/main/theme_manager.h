#ifndef THEME_MANAGER_H
#define THEME_MANAGER_H

#include "lvgl.h"
#include <stdbool.h>

#define THEME_NVS_NAMESPACE "ui_cfg"
#define THEME_NVS_KEY "theme_dark" // 1 for dark, 0 for light

typedef enum {
    THEME_LIGHT,
    THEME_DARK
} app_theme_t;

void theme_manager_init(void);
void theme_manager_apply_theme(lv_disp_t *disp, app_theme_t theme_mode);
app_theme_t theme_manager_get_current_theme(void);
void theme_manager_toggle_theme(lv_disp_t *disp);
void theme_manager_save_theme(app_theme_t theme_mode);

#endif // THEME_MANAGER_H