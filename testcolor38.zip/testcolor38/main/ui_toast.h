#ifndef UI_TOAST_H
#define UI_TOAST_H

#include "lvgl.h"

void ui_toast_show(lv_obj_t* parent_screen, const char* message, uint32_t duration_ms, bool error);

#endif // UI_TOAST_H