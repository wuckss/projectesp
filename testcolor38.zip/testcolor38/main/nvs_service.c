#include "nvs_service.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "esp_log.h"

#define NVS_SERVICE_TAG "NVS_SERVICE"

void nvs_service_init(void) {
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);
    ESP_LOGI(NVS_SERVICE_TAG, "NVS Initialized.");
}

esp_err_t nvs_service_set_str(const char* namespace_name, const char* key, const char* value) {
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open(namespace_name, NVS_READWRITE, &nvs_handle);
    if (err != ESP_OK) return err;
    err = nvs_set_str(nvs_handle, key, value);
    if (err == ESP_OK) err = nvs_commit(nvs_handle);
    nvs_close(nvs_handle);
    return err;
}

esp_err_t nvs_service_get_str(const char* namespace_name, const char* key, char* out_value, size_t* length) {
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open(namespace_name, NVS_READONLY, &nvs_handle);
    if (err != ESP_OK) return err;
    err = nvs_get_str(nvs_handle, key, out_value, length);
    nvs_close(nvs_handle);
    return err;
}

esp_err_t nvs_service_set_u8(const char* namespace_name, const char* key, uint8_t value) {
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open(namespace_name, NVS_READWRITE, &nvs_handle);
    if (err != ESP_OK) return err;
    err = nvs_set_u8(nvs_handle, key, value);
    if (err == ESP_OK) err = nvs_commit(nvs_handle);
    nvs_close(nvs_handle);
    return err;
}

esp_err_t nvs_service_get_u8(const char* namespace_name, const char* key, uint8_t* out_value) {
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open(namespace_name, NVS_READONLY, &nvs_handle);
    if (err != ESP_OK) return err;
    err = nvs_get_u8(nvs_handle, key, out_value);
    nvs_close(nvs_handle);
    return err;
}

// Similar implementations for i32 etc.
esp_err_t nvs_service_set_i32(const char* namespace_name, const char* key, int32_t value) {
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open(namespace_name, NVS_READWRITE, &nvs_handle);
    if (err != ESP_OK) return err;
    err = nvs_set_i32(nvs_handle, key, value);
    if (err == ESP_OK) err = nvs_commit(nvs_handle);
    nvs_close(nvs_handle);
    return err;
}

esp_err_t nvs_service_get_i32(const char* namespace_name, const char* key, int32_t* out_value) {
    nvs_handle_t nvs_handle;
    esp_err_t err = nvs_open(namespace_name, NVS_READONLY, &nvs_handle);
    if (err != ESP_OK) return err;
    err = nvs_get_i32(nvs_handle, key, out_value);
    nvs_close(nvs_handle);
    return err;
}