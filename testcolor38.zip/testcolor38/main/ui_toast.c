// In /Users/wasimhafez/Espressif/testcolor38/main/ui_toast.c
#include "ui_toast.h"
#include "esp_log.h"
#include "lvgl.h" // Ensure LVGL is included for lv_timer_t, lv_obj_del_async etc.

#define UI_TOAST_TAG "UI_TOAST"

// CORRECTED SIGNATURE for lv_timer_create callback
static void toast_delete_timer_cb(lv_timer_t * timer) {
    // The user_data for this timer is the toast_label itself
    lv_obj_t * toast_label = (lv_obj_t *)timer->user_data; 
    if (toast_label) {
        ESP_LOGD(UI_TOAST_TAG, "Toast timer expired, deleting toast label: %p", (void*)toast_label);
        lv_obj_del_async(toast_label); // Delete the label (which is the toast object in this impl)
    }
    // The timer itself will be deleted automatically by LVGL as it's a one-shot timer.
}

void ui_toast_show(lv_obj_t* parent_screen, const char* message, uint32_t duration_ms, bool is_error) {
    if (!parent_screen) {
        parent_screen = lv_scr_act(); 
    }
    if (!parent_screen) {
        ESP_LOGE(UI_TOAST_TAG, "Cannot show toast, no parent screen active.");
        return;
    }

    // Simple approach: Delete any previous toast that might be a direct child label with floating flag.
    // This is not perfectly robust. A better way would be to store a static lv_obj_t* for the current toast.
    for(uint32_t i = 0; i < lv_obj_get_child_cnt(parent_screen); i++) {
        lv_obj_t * child = lv_obj_get_child(parent_screen, i);
        if(child && lv_obj_has_flag(child, LV_OBJ_FLAG_FLOATING) && lv_obj_get_user_data(child) == (void*)0xDEADBEEF) { // Using a magic number as user_data
            ESP_LOGD(UI_TOAST_TAG, "Deleting existing toast: %p", (void*)child);
            lv_timer_t* old_timer = (lv_timer_t*)lv_obj_get_user_data(lv_obj_get_child(child, 0)); // Assuming timer was stored on a child or specific part
            if(old_timer) {
                lv_timer_del(old_timer);
            }
            lv_obj_del_async(child);
            break; // Assume only one toast at a time
        }
    }

    lv_obj_t *toast_label = lv_label_create(parent_screen);
    lv_label_set_text(toast_label, message);
    lv_obj_set_width(toast_label, LV_PCT(80));
    lv_obj_set_style_bg_opa(toast_label, LV_OPA_COVER, 0);
    lv_obj_set_style_bg_color(toast_label, is_error ? lv_palette_main(LV_PALETTE_RED) : lv_palette_darken(LV_PALETTE_GREY, 2), 0);
    lv_obj_set_style_text_color(toast_label, lv_color_white(), 0);
    lv_obj_set_style_pad_all(toast_label, 10, 0);
    lv_obj_set_style_radius(toast_label, 5, 0);
    lv_obj_set_style_text_align(toast_label, LV_TEXT_ALIGN_CENTER, 0);

    lv_obj_align(toast_label, LV_ALIGN_BOTTOM_MID, 0, -20);
    lv_obj_add_flag(toast_label, LV_OBJ_FLAG_FLOATING); // Ensure it's on top
    lv_obj_set_user_data(toast_label, (void*)0xDEADBEEF); // Magic number to identify it as our toast

    ESP_LOGI(UI_TOAST_TAG, "Showing toast: %s on screen %p", message, (void*)parent_screen);

    // Create a timer to delete this specific toast_label
    lv_timer_t * timer = lv_timer_create(toast_delete_timer_cb, duration_ms, toast_label); // Pass toast_label as user_data
    lv_timer_set_repeat_count(timer, 1);
    // Storing timer on a child of toast_label or a dedicated structure would be more robust if toast_label itself is complex.
    // For simplicity, if toast_label *is* the toast, this is fine.
    // lv_obj_set_user_data(lv_obj_create(toast_label), timer); // Example if timer stored on an invisible child
}