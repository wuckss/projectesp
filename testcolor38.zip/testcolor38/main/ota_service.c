#include "ota_service.h"
#include "esp_ota_ops.h"
#include "esp_http_client.h"
#include "esp_https_ota.h"
#include "esp_log.h"
#include "string.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "esp_system.h" // For esp_restart
#include "esp_app_format.h" // For esp_app_desc_t

#define OTA_TAG "OTA_SERVICE"
#define OTA_BUFFER_SIZE 2048 // Should be at least the size of a flash sector (4096) for efficiency

static ota_status_cb_t g_ota_status_cb = NULL;
static ota_status_t current_ota_status = OTA_IDLE;
static char ota_update_url[256];

// Server certificate (PEM format) for HTTPS OTA if your S3 bucket uses HTTPS with a non-standard CA
// If S3 uses standard Amazon CA, this might not be strictly needed if ESP-IDF has updated cert bundle
// For testing, you might use HTTP or ensure your S3 URL is correctly handled.
extern const uint8_t server_cert_pem_start[] asm("_binary_s3_server_crt_pem_start");
extern const uint8_t server_cert_pem_end[] asm("_binary_s3_server_crt_pem_end");

// Make sure to add your S3 certificate to your project's components directory
// (e.g., main/certs/s3_server.crt) and reference it in CMakeLists.txt:
// target_add_binary_data(${COMPONENT_TARGET} "certs/s3_server.crt.pem" TEXT)


static void ota_task(void *pvParameter) {
    ESP_LOGI(OTA_TAG, "Starting OTA task for URL: %s", ota_update_url);
    current_ota_status = OTA_IN_PROGRESS;
    if (g_ota_status_cb) g_ota_status_cb(OTA_IN_PROGRESS, 0);

    esp_http_client_config_t config = {
        .url = ota_update_url,
        .cert_pem = (char *)server_cert_pem_start, // Comment out if not using custom cert or HTTP
        .timeout_ms = 15000, // 15 seconds
        .keep_alive_enable = true,
        .buffer_size = OTA_BUFFER_SIZE,
        .buffer_size_tx = 2048, // For request headers
    };

    // Check if current app is valid to prevent rollback to corrupted app
    const esp_partition_t *running = esp_ota_get_running_partition();
    esp_app_desc_t running_app_info;
    if (esp_ota_get_partition_description(running, &running_app_info) == ESP_OK) {
        ESP_LOGI(OTA_TAG, "Running firmware version: %s", running_app_info.version);
    }


    esp_https_ota_config_t ota_config = {
        .http_config = &config,
    };

    esp_err_t ret = esp_https_ota(&ota_config);
    if (ret == ESP_OK) {
        ESP_LOGI(OTA_TAG, "OTA Update Successful! Rebooting...");
        current_ota_status = OTA_SUCCESS;
        if (g_ota_status_cb) g_ota_status_cb(OTA_SUCCESS, 100);
        vTaskDelay(pdMS_TO_TICKS(2000)); // Give time for UI update/log
        esp_restart();
    } else {
        ESP_LOGE(OTA_TAG, "OTA Update Failed: %s", esp_err_to_name(ret));
        current_ota_status = OTA_FAILED;
        if (g_ota_status_cb) g_ota_status_cb(OTA_FAILED, 0);

        // If update fails, ensure we revert to a valid partition if needed
        esp_err_t err = esp_ota_mark_app_invalid_rollback_and_reboot();
        if (err != ESP_OK) { // Should not happen if current app is valid
             ESP_LOGE(OTA_TAG, "Failed to mark app invalid or rollback: %s", esp_err_to_name(err));
             // Fallback: try to restart current app if rollback mechanism itself fails.
             esp_restart();
        }
        // esp_ota_mark_app_invalid_rollback_and_reboot will restart.
    }
    vTaskDelete(NULL);
}

void ota_service_init(ota_status_cb_t callback) {
    g_ota_status_cb = callback;
    current_ota_status = OTA_IDLE;
    ESP_LOGI(OTA_TAG, "OTA Service Initialized.");

    // Verify rollback status on boot
    const esp_partition_t *running = esp_ota_get_running_partition();
    esp_ota_img_states_t ota_state;
    if (esp_ota_get_state_partition(running, &ota_state) == ESP_OK) {
        if (ota_state == ESP_OTA_IMG_PENDING_VERIFY) {
            ESP_LOGI(OTA_TAG, "First boot after OTA. Verifying app and marking as valid.");
            // Here you would perform any critical self-tests.
            // For simplicity, we assume the app is fine if it boots this far.
            esp_err_t err = esp_ota_mark_app_valid_cancel_rollback();
            if (err != ESP_OK) {
                ESP_LOGE(OTA_TAG, "Failed to mark app valid: %s. Rolling back...", esp_err_to_name(err));
                esp_ota_mark_app_invalid_rollback_and_reboot(); // Will restart.
            } else {
                 ESP_LOGI(OTA_TAG, "App marked as valid.");
            }
        } else if (ota_state == ESP_OTA_IMG_VALID || ota_state == ESP_OTA_IMG_UNDEFINED) {
            ESP_LOGI(OTA_TAG, "App is valid or no OTA state.");
        } else {
            ESP_LOGE(OTA_TAG, "App is in an unexpected OTA state: %d. Attempting rollback.", ota_state);
            esp_ota_mark_app_invalid_rollback_and_reboot(); // Will restart.
        }
    }
}

void ota_service_start_update(const char *ota_bin_url) {
    if (current_ota_status == OTA_IN_PROGRESS) {
        ESP_LOGW(OTA_TAG, "OTA update already in progress.");
        return;
    }
    if (!ota_bin_url || strlen(ota_bin_url) == 0) {
        ESP_LOGE(OTA_TAG, "OTA URL is empty.");
        if (g_ota_status_cb) g_ota_status_cb(OTA_FAILED, 0);
        return;
    }
    strncpy(ota_update_url, ota_bin_url, sizeof(ota_update_url) - 1);
    ota_update_url[sizeof(ota_update_url) - 1] = '\0';

    xTaskCreate(&ota_task, "ota_task", 8192, NULL, 5, NULL);
}

ota_status_t ota_service_get_status(void) {
    return current_ota_status;
}