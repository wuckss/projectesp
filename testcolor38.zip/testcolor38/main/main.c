#include <stdio.h>
// #include "sdkconfig.h" // Usually brought in by other ESP-IDF headers if specific configs are used directly
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h" // For semaphores if used, not directly in this main
#include "esp_timer.h"
#include "esp_log.h"
#include "esp_err.h"      // For esp_err_t
// #include "lvgl.h" // Included via ui.h

// Custom project headers
#include "nvs_service.h"
// #include "wifi_manager.h" // Included via ui_custom_events.h or directly if needed
#include "theme_manager.h"
#include "ui_custom_events.h" // This should include wifi_manager.h if it uses it extensively
#include "ui/ui.h"            // This should include lvgl.h

// BSP / Display specific headers - VERY IMPORTANT
// Ensure the component providing these (e.g., a Waveshare BSP component or similar)
// is listed in main/CMakeLists.txt REQUIRES section,
// and that these headers are accessible.
// If your BSP functions are in "esp_lcd_touch_gt911.h" or another known header, include that.
// For example, if you have a general BSP header:
// #include "bsp/display.h"
// Or if they come from the touch component directly (less common for bsp_ prefix):
// #include "esp_lcd_touch_gt911.h" // Or "esp_lcd_touch.h" if it's more generic

// --- Fallback: Explicitly declare BSP functions if their header isn't resolved ---
// --- This is a workaround; the proper solution is to include the correct BSP header ---
// --- and ensure the component is linked. ---
// esp_err_t bsp_display_start(void);
// lv_disp_t *bsp_display_lvgl_init(void);
// void bsp_display_backlight_on(void); // If you intend to use it later

static const char *TAG_MAIN = "app_main_v2";

// LVGL Tick Task
static void lv_tick_task(void *arg) {
    (void)arg;
    // CONFIG_LV_TICK_PERIOD_MS should be available if LVGL is configured via menuconfig
    // If still an error, ensure 'idf.py menuconfig' -> Component config -> LVGL configuration is saved.
    // As a temporary workaround if Kconfig is not picked up, define it (e.g., to 10ms)
    // #define LV_TICK_PERIOD_MS_WORKAROUND 10
    // lv_tick_inc(LV_TICK_PERIOD_MS_WORKAROUND);
    lv_tick_inc(CONFIG_LV_TICK_PERIOD_MS);
}

// LVGL Task
static void lvgl_task(void *pvParameter) {
    (void)pvParameter;

    // Tick interface for LVGL
    const esp_timer_create_args_t periodic_timer_args = {
        .callback = &lv_tick_task,
        .name = "periodic_gui"};
    esp_timer_handle_t periodic_timer;
    ESP_ERROR_CHECK(esp_timer_create(&periodic_timer_args, &periodic_timer));
    // CONFIG_LV_TICK_PERIOD_MS, see comment in lv_tick_task
    ESP_ERROR_CHECK(esp_timer_start_periodic(periodic_timer, CONFIG_LV_TICK_PERIOD_MS * 1000));

    ESP_LOGI(TAG_MAIN, "LVGL task started.");
    while (1) {
        lv_timer_handler();
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

void app_main(void) {
    ESP_LOGI(TAG_MAIN, "App Main started.");

    // 1. Initialize NVS
    esp_err_t nvs_ret = nvs_service_init(); // Ensure nvs_service.h declares esp_err_t nvs_service_init(void);
    if (nvs_ret == ESP_OK) {
        ESP_LOGI(TAG_MAIN, "NVS Initialized.");
    } else {
        ESP_LOGE(TAG_MAIN, "NVS Initialization Failed! (Error: %s)", esp_err_to_name(nvs_ret));
        // Consider a more robust error handling, like reformatting NVS or halting.
    }

    // 2. Initialize Display and LVGL (BSP functions)
    ESP_LOGI(TAG_MAIN, "Initializing display hardware (BSP)...");
    // These functions (bsp_display_start, bsp_display_lvgl_init)
    // must be declared in a header included above, and the component providing them
    // must be in main/CMakeLists.txt REQUIRES.
    // If they are not found, the build will fail. This is a common point of failure
    // if the BSP isn't set up or linked correctly.
    if (bsp_display_start() != ESP_OK) {
        ESP_LOGE(TAG_MAIN, "BSP Display Start Failed!");
        return; // Critical failure
    }

    ESP_LOGI(TAG_MAIN, "Initializing LVGL via BSP...");
    lv_disp_t *disp = bsp_display_lvgl_init(); // Ensure this is declared to return lv_disp_t*
    if (!disp) {
        ESP_LOGE(TAG_MAIN, "LVGL initialization failed via BSP!");
        return; // Critical failure
    }
    // bsp_display_backlight_on(); // Call if needed and provided by BSP

    // --- OTA and Backlight Control are deferred for now ---
    // backlight_control_init();

    // 3. Initialize SquareLine UI
    ui_init();
    ESP_LOGI(TAG_MAIN, "LVGL UI Initialized (ui_init done).");

    // 4. Initialize Wi-Fi Manager and Custom UI Callbacks/Events
    app_wifi_manager_register_callbacks();
    ESP_LOGI(TAG_MAIN, "Wi-Fi Manager Initialized & Callbacks Registered.");

    custom_ui_event_init();
    ESP_LOGI(TAG_MAIN, "Custom UI Event Handlers Initialized.");

    // Add screen load event handlers (ensure callbacks are defined and accessible)
    if (ui_WifiScreen && wifi_screen_load_event_cb) {
        lv_obj_add_event_cb(ui_WifiScreen, wifi_screen_load_event_cb, LV_EVENT_SCREEN_LOAD_START, NULL);
    } else {
        ESP_LOGW(TAG_MAIN, "ui_WifiScreen or wifi_screen_load_event_cb is NULL during event setup!");
    }
    if (ui_WifiPasswordScreen1 && password_screen_load_event_cb) {
        lv_obj_add_event_cb(ui_WifiPasswordScreen1, password_screen_load_event_cb, LV_EVENT_SCREEN_LOAD_START, NULL);
    } else {
        ESP_LOGW(TAG_MAIN, "ui_WifiPasswordScreen1 or password_screen_load_event_cb is NULL during event setup!");
    }

    // 5. Initialize Theme Manager
    // Ensure theme_manager_init is declared as `void theme_manager_init(lv_disp_t *disp);` in theme_manager.h
    theme_manager_init(disp);
    // Ensure theme_manager.h declares `void theme_manager_apply_theme(void);` and `void theme_manager_load_theme(void);`
    // Or, if `theme_manager_load_and_apply_theme` exists, ensure it's declared.
    // Based on errors and likely intent:
    theme_manager_load_theme();
    theme_manager_apply_theme();
    ESP_LOGI(TAG_MAIN, "Theme Manager Initialized and theme applied.");

    // 6. Create LVGL Task
    BaseType_t task_res = xTaskCreate(lvgl_task, "lvgl_task", 4096 * 2, NULL, 5, NULL);
    if (task_res != pdPASS) {
        ESP_LOGE(TAG_MAIN, "Failed to create LVGL task. Result: %d", task_res);
        return;
    }
    ESP_LOGI(TAG_MAIN, "LVGL Task Created.");

    ESP_LOGI(TAG_MAIN, "Initialization complete. Main loop yielding.");
}