// components/ui/src/ui_events.c
#include "../ui.h" // Assumes ui.h is in components/ui/include and CMake handles path
#include "ui_events.h"
#include <string.h>
#include "esp_log.h"
#include "wifi_manager.h" // For wifi_manager_connect()

static const char *UI_EVENTS_TAG = "UI_EVENTS";

#define MAX_SSID_LEN_FOR_UI 32 // Should match WIFI_MANAGER_MAX_SSID_LEN
static char selected_ssid_from_roller[MAX_SSID_LEN_FOR_UI + 1] = {0};

void ui_events_set_selected_ssid(const char* ssid) {
    if (ssid) {
        strncpy(selected_ssid_from_roller, ssid, MAX_SSID_LEN_FOR_UI);
        selected_ssid_from_roller[MAX_SSID_LEN_FOR_UI] = '\0';
        ESP_LOGI(UI_EVENTS_TAG, "Selected SSID for password entry: %s", selected_ssid_from_roller);
    } else {
        selected_ssid_from_roller[0] = '\0'; // Clear if NULL is passed
        ESP_LOGW(UI_EVENTS_TAG, "Attempted to set NULL or empty SSID.");
    }
}

const char* ui_events_get_selected_ssid(void) {
    if (strlen(selected_ssid_from_roller) > 0) {
        return selected_ssid_from_roller;
    }
    ESP_LOGW(UI_EVENTS_TAG, "Requested selected SSID, but none is set.");
    return NULL; // Or return an empty string ""
}

// LVGL task callback to actually show the toast
void show_toast_task_cb(void *param) {
    if (param == NULL) {
        ESP_LOGE(UI_EVENTS_TAG, "Toast task callback received NULL param.");
        return;
    }
    char *message = (char *)param;
    ESP_LOGD(UI_EVENTS_TAG, "LV_ASYNC (Toast): Displaying: %s", message);

    lv_obj_t * active_screen = lv_scr_act();
    if (!active_screen) {
        ESP_LOGE(UI_EVENTS_TAG, "Cannot show toast, no active screen! Message: %s", message);
        free(message); // Free the message if we can't show it
        return;
    }

    lv_obj_t *toast_obj = lv_label_create(active_screen);
    lv_label_set_text(toast_obj, message);

    lv_obj_set_style_bg_color(toast_obj, lv_color_hex(0x333333), 0);
    lv_obj_set_style_bg_opa(toast_obj, LV_OPA_80, 0);
    lv_obj_set_style_text_color(toast_obj, lv_color_white(), 0);
    lv_obj_set_style_pad_all(toast_obj, 8, 0); // Slightly smaller padding
    lv_obj_set_style_radius(toast_obj, 4, 0); // Slightly smaller radius
    lv_obj_set_style_text_align(toast_obj, LV_TEXT_ALIGN_CENTER, 0);
    
    lv_obj_align(toast_obj, LV_ALIGN_BOTTOM_MID, 0, -15); // Adjust position
    lv_obj_add_flag(toast_obj, LV_OBJ_FLAG_FLOATING);

    lv_obj_del_delayed(toast_obj, 3000); // Delete after 3 seconds
    free(message); // Free the duplicated message string
}

// Wrapper to call from non-LVGL tasks.
// message_ptr MUST be dynamically allocated (e.g., from strdup) as it will be freed by show_toast_task_cb.
void show_toast_message_async_wrapper(void* message_ptr) {
    if (!message_ptr) {
        ESP_LOGE(UI_EVENTS_TAG, "show_toast_message_async_wrapper called with NULL message_ptr");
        return;
    }
    if (lv_async_call(show_toast_task_cb, message_ptr) != LV_RES_OK) {
        ESP_LOGE(UI_EVENTS_TAG, "lv_async_call for toast failed to queue. Freeing message: %s", (char*)message_ptr);
        free(message_ptr); // Free if not queued
    }
}

void restartdevicefunction(lv_event_t *e) {
    ESP_LOGI(UI_EVENTS_TAG, "Restart device function called.");
    char* msg_copy = strdup("Restarting device...");
    if(msg_copy) {
        show_toast_message_async_wrapper(msg_copy);
        // Add a small delay to allow the toast message to be processed by LVGL
        // before the device actually restarts.
        // This delay runs in the LVGL task, so it's okay.
        lv_timer_create_basic_delete_after_exec((void (*)(lv_timer_t*))esp_restart, 500, NULL);
    } else {
        esp_restart(); // Fallback if strdup fails
    }
}

void passwordsubmitted(lv_event_t *e) {
    const char *ssid = ui_events_get_selected_ssid();
    const char *password = NULL;

    if (ui_TextArea1) { // Ensure ui_TextArea1 is valid
        password = lv_textarea_get_text(ui_TextArea1);
    } else {
        ESP_LOGE(UI_EVENTS_TAG, "ui_TextArea1 is NULL in passwordsubmitted!");
        char* msg_copy = strdup("UI Error: Pwd Field");
        if(msg_copy) show_toast_message_async_wrapper(msg_copy);
        return;
    }

    if (ssid && strlen(ssid) > 0 && password) { // Password can be empty for open networks, though we don't handle that explicitly here
        ESP_LOGI(UI_EVENTS_TAG, "Password submitted for SSID: '%s'", ssid);
        
        char* msg_copy = strdup("Connecting...");
        if(msg_copy) show_toast_message_async_wrapper(msg_copy);
        
        esp_err_t connect_err = wifi_manager_connect(ssid, password);
        if (connect_err != ESP_OK) {
            ESP_LOGE(UI_EVENTS_TAG, "wifi_manager_connect call failed to initiate: %s", esp_err_to_name(connect_err));
            // Specific error toasts ("Wrong Password", "AP Not Found") are handled by wifi_manager event handler.
            // A generic "Connection start failed" might be shown by wifi_manager_connect itself.
        }
    } else {
        ESP_LOGE(UI_EVENTS_TAG, "SSID or Password missing for connection attempt. SSID: %p, Pass: %p", ssid, password);
        char* msg_copy = strdup("SSID missing or UI Error.");
        if(msg_copy) show_toast_message_async_wrapper(msg_copy);
    }

    // Clear the password field and optionally hide keyboard
    if (ui_TextArea1) lv_textarea_set_text(ui_TextArea1, "");
    if (ui_Keyboard1 && lv_obj_is_valid(ui_Keyboard1)) {
      // Check if keyboard should be hidden. SquareLine might handle this based on Keyboard1's own events.
      // Forcing hide: lv_obj_add_flag(ui_Keyboard1, LV_OBJ_FLAG_HIDDEN);
    }
}