#ifndef OTA_SERVICE_H
#define OTA_SERVICE_H

#include "esp_event.h"
//#include "esp_http_client.h"

typedef enum {
    OTA_IDLE,
    OTA_IN_PROGRESS,
    OTA_SUCCESS,
    OTA_FAILED,
    OTA_NO_UPDATE_AVAILABLE
} ota_status_t;

typedef void (*ota_status_cb_t)(ota_status_t status, int progress);

void ota_service_init(ota_status_cb_t callback);
void ota_service_start_update(const char *ota_url);
ota_status_t ota_service_get_status(void);

#endif // OTA_SERVICE_H