#ifndef UI_CUSTOM_EVENTS_H
#define UI_CUSTOM_EVENTS_H

#include "lvgl.h"
#include "wifi_manager.h" // For wifi_manager_status_t and wifi_ap_record_t

#ifdef __cplusplus
extern "C" {
#endif

// --- Wi-Fi Related ---
// Navigation
void event_handler_go_to_wifi_screen(lv_event_t *e); // For SettingsButtonWifi and WifiDropDown

// ui_WifiScreen events
void wifi_screen_load_event_cb(lv_event_t *e); // Called on LV_EVENT_SCREEN_LOAD_START for ui_WifiScreen
void event_handler_wifi_roller_continue(lv_event_t *e); // For ui_Button9 on WifiScreen

// ui_WifiPasswordScreen1 events
void password_screen_load_event_cb(lv_event_t * e); // For LV_EVENT_SCREEN_LOAD_START for ui_WifiPasswordScreen1
void password_submit_event_handler(lv_event_t *e); // For ui_Keyboard1 LV_EVENT_READY/APPLY

// Callbacks for wifi_manager
void app_wifi_status_update_callback(wifi_manager_status_t status, void *user_data);
void app_wifi_scan_done_callback(uint16_t ap_count, wifi_ap_record_t *ap_records, void *user_data);

void app_wifi_manager_register_callbacks(void); // To call wifi_manager_init with app callbacks
void custom_ui_event_init(void); // To initialize all custom static UI event handlers


// --- Settings Screen Callbacks (Declarations for later) ---
void event_handler_restart_button(lv_event_t *e);
void event_handler_brightness_slider(lv_event_t *e);
void event_handler_theme_switch(lv_event_t *e);
void event_handler_check_for_update_button(lv_event_t *e);


#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif // UI_CUSTOM_EVENTS_H